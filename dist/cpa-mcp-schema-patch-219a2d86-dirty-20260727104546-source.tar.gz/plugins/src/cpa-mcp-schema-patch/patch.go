package main

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"strings"

	"github.com/router-for-me/CLIProxyAPI/v7/sdk/pluginapi"
)

type patchResult struct {
	Changed      bool
	BeforeBody   []byte
	AfterBody    []byte
	PatchedTools []string
	SkippedTools []string
	MissingTools []string
}

func interceptRequestBeforeAuth(ctx context.Context, req pluginapi.RequestInterceptRequest, hostCallbackID string) pluginapi.RequestInterceptResponse {
	_ = ctx
	return applySchemaPatchToIntercept(schemaPatchRequestContext{
		Body:           req.Body,
		Model:          req.Model,
		RequestedModel: req.RequestedModel,
		SourceFormat:   req.SourceFormat,
		ToFormat:       req.ToFormat,
		Stream:         req.Stream,
		Stage:          "intercept_before",
		HostCallbackID: hostCallbackID,
		Metadata:       req.Metadata,
	})
}

func interceptRequestAfterAuth(ctx context.Context, req pluginapi.RequestInterceptRequest, hostCallbackID string) pluginapi.RequestInterceptResponse {
	_ = ctx
	return applySchemaPatchToIntercept(schemaPatchRequestContext{
		Body:           req.Body,
		Model:          req.Model,
		RequestedModel: req.RequestedModel,
		SourceFormat:   req.SourceFormat,
		ToFormat:       req.ToFormat,
		Stream:         req.Stream,
		Stage:          "intercept_after",
		HostCallbackID: hostCallbackID,
		Metadata:       req.Metadata,
	})
}

func finalizeRequest(ctx context.Context, req pluginapi.RequestFinalizeRequest, hostCallbackID string) pluginapi.RequestFinalizeResponse {
	_ = ctx
	interceptResponse := applySchemaPatchToIntercept(schemaPatchRequestContext{
		Body:           req.Body,
		Model:          req.Model,
		RequestedModel: req.RequestedModel,
		SourceFormat:   req.SourceFormat,
		ToFormat:       req.ToFormat,
		Stream:         req.Stream,
		Stage:          "finalize",
		HostCallbackID: hostCallbackID,
		Metadata:       req.Metadata,
	})
	return pluginapi.RequestFinalizeResponse{Body: interceptResponse.Body}
}

type schemaPatchRequestContext struct {
	Body           []byte
	Model          string
	RequestedModel string
	SourceFormat   string
	ToFormat       string
	Stream         bool
	Stage          string
	HostCallbackID string
	Metadata       map[string]any
}

func applySchemaPatchToIntercept(req schemaPatchRequestContext) pluginapi.RequestInterceptResponse {
	if len(bytes.TrimSpace(req.Body)) == 0 {
		return pluginapi.RequestInterceptResponse{}
	}
	result, errPatch := patchMcpToolSchemasInRequestBody(req.Body, onlyEmptyEnabled())
	if errPatch != nil {
		logPluginWarn(req.HostCallbackID, "mcp schema patch skipped", map[string]any{
			"reason":        "patch_error",
			"error":         errPatch.Error(),
			"stage":         req.Stage,
			"model":         req.Model,
			"source_format": req.SourceFormat,
			"to_format":     req.ToFormat,
		})
		return pluginapi.RequestInterceptResponse{}
	}
	if !result.Changed {
		logPluginDebug(req.HostCallbackID, "mcp schema patch skipped", map[string]any{
			"reason":         "no_change",
			"stage":          req.Stage,
			"model":          req.Model,
			"source_format":  req.SourceFormat,
			"to_format":      req.ToFormat,
			"skipped_tools":  result.SkippedTools,
			"missing_tools":  result.MissingTools,
			"request_id":     metadataString(req.Metadata, "request_id"),
			"registry_count": len(currentSchemaRegistry().toolNames),
		})
		return pluginapi.RequestInterceptResponse{}
	}

	requestID := metadataString(req.Metadata, "request_id")
	requestPath := metadataString(req.Metadata, "request_path")
	if requestPath == "" {
		requestPath = req.SourceFormat
	}

	logPluginInfo(req.HostCallbackID, "mcp tool schemas patched", map[string]any{
		"stage":          req.Stage,
		"model":          req.Model,
		"source_format":  req.SourceFormat,
		"to_format":      req.ToFormat,
		"patched_tools":  result.PatchedTools,
		"skipped_tools":  result.SkippedTools,
		"missing_tools":  result.MissingTools,
		"request_id":     requestID,
		"request_path":   requestPath,
		"before_bytes":   len(result.BeforeBody),
		"after_bytes":    len(result.AfterBody),
	})

	if detailLogEnabled() {
		logPath, errWrite := writePatchDetailLog(patchDetailLogInput{
			RequestID:      requestID,
			RequestPath:    requestPath,
			SourceFormat:   req.SourceFormat,
			ToFormat:       req.ToFormat,
			Model:          req.Model,
			RequestedModel: req.RequestedModel,
			Stream:         req.Stream,
			Stage:          req.Stage,
			Result:         result,
		})
		if errWrite != nil {
			logPluginInfo(req.HostCallbackID, "mcp schema patch detail log failed", map[string]any{
				"error":      errWrite.Error(),
				"request_id": requestID,
				"stage":      req.Stage,
			})
		} else {
			logPluginDebug(req.HostCallbackID, "mcp schema patch detail log written", map[string]any{
				"path":       logPath,
				"request_id": requestID,
				"stage":      req.Stage,
			})
		}
	}

	return pluginapi.RequestInterceptResponse{Body: result.AfterBody}
}

func patchMcpToolSchemasInRequestBody(body []byte, onlyEmpty bool) (patchResult, error) {
	result := patchResult{
		BeforeBody: bytes.Clone(body),
	}
	var root any
	if errUnmarshal := json.Unmarshal(body, &root); errUnmarshal != nil {
		return result, fmt.Errorf("unmarshal request body: %w", errUnmarshal)
	}
	rootMap, okRootMap := root.(map[string]any)
	if !okRootMap {
		return result, nil
	}

	changed := false
	if toolsValue, hasTools := rootMap["tools"]; hasTools {
		toolsChanged, patched, skipped, missing := patchToolsValue(toolsValue, onlyEmpty)
		if toolsChanged {
			rootMap["tools"] = toolsValue
			changed = true
		}
		result.PatchedTools = append(result.PatchedTools, patched...)
		result.SkippedTools = append(result.SkippedTools, skipped...)
		result.MissingTools = append(result.MissingTools, missing...)
	}

	// Some OpenAI-compatible payloads nest tools under other keys; keep minimal surface for now.
	if !changed && len(result.PatchedTools) == 0 {
		result.AfterBody = bytes.Clone(body)
		return result, nil
	}

	afterBody, errMarshal := json.Marshal(rootMap)
	if errMarshal != nil {
		return result, fmt.Errorf("marshal patched request body: %w", errMarshal)
	}
	result.AfterBody = afterBody
	result.Changed = !bytes.Equal(result.BeforeBody, result.AfterBody)
	if !result.Changed {
		result.AfterBody = bytes.Clone(body)
	}
	return result, nil
}

func patchToolsValue(toolsValue any, onlyEmpty bool) (bool, []string, []string, []string) {
	switch typed := toolsValue.(type) {
	case []any:
		changed := false
		var patched []string
		var skipped []string
		var missing []string
		for index := range typed {
			toolMap, okToolMap := typed[index].(map[string]any)
			if !okToolMap {
				continue
			}
			toolChanged, toolName, reason := patchOneTool(toolMap, onlyEmpty)
			if toolChanged {
				typed[index] = toolMap
				changed = true
				patched = appendUnique(patched, toolName)
				continue
			}
			switch reason {
			case "not_empty", "no_schema_field":
				skipped = appendUnique(skipped, toolName)
			case "not_in_registry":
				if toolName != "" && isEmptyToolSchema(toolMap) {
					missing = appendUnique(missing, toolName)
				}
			}
		}
		return changed, patched, skipped, missing
	default:
		return false, nil, nil, nil
	}
}

// patchOneTool mutates toolMap in place when a replacement schema is applied.
// reason: "", "not_empty", "not_in_registry", "no_schema_field", "unnamed"
func patchOneTool(toolMap map[string]any, onlyEmpty bool) (bool, string, string) {
	if toolMap == nil {
		return false, "", "unnamed"
	}

	// OpenAI function wrapper: { "type":"function", "function": { "name":..., "parameters":... } }
	if functionValue, hasFunction := toolMap["function"]; hasFunction {
		if functionMap, okFunctionMap := functionValue.(map[string]any); okFunctionMap {
			changed, toolName, reason := patchOneTool(functionMap, onlyEmpty)
			if changed {
				toolMap["function"] = functionMap
			}
			return changed, toolName, reason
		}
	}

	toolName := toolNameFromMap(toolMap)
	if toolName == "" {
		return false, "", "unnamed"
	}

	schemaKey, rawSchema, hasSchemaField := locateSchemaField(toolMap)
	if !hasSchemaField {
		// No schema field at all: if registry has definition, create input_schema (Anthropic default).
		registrySchema, exists := lookupToolSchema(toolName)
		if !exists {
			return false, toolName, "not_in_registry"
		}
		if onlyEmpty {
			toolMap["input_schema"] = registrySchema
			return true, toolName, ""
		}
		toolMap["input_schema"] = registrySchema
		return true, toolName, ""
	}

	if onlyEmpty && !isEmptySchemaValue(rawSchema) {
		return false, toolName, "not_empty"
	}

	registrySchema, exists := lookupToolSchema(toolName)
	if !exists {
		return false, toolName, "not_in_registry"
	}

	toolMap[schemaKey] = registrySchema
	return true, toolName, ""
}

func locateSchemaField(toolMap map[string]any) (string, any, bool) {
	for _, key := range []string{"input_schema", "parameters", "arguments", "inputSchema"} {
		if raw, exists := toolMap[key]; exists {
			return key, raw, true
		}
	}
	return "", nil, false
}

func toolNameFromMap(toolMap map[string]any) string {
	if nameValue, hasName := toolMap["name"]; hasName {
		if nameString, okNameString := nameValue.(string); okNameString {
			return strings.TrimSpace(nameString)
		}
	}
	return ""
}

func isEmptyToolSchema(toolMap map[string]any) bool {
	_, rawSchema, hasSchemaField := locateSchemaField(toolMap)
	if !hasSchemaField {
		return true
	}
	return isEmptySchemaValue(rawSchema)
}

func isEmptySchemaValue(raw any) bool {
	if raw == nil {
		return true
	}
	switch typed := raw.(type) {
	case map[string]any:
		return isEmptySchemaObject(typed)
	case string:
		trimmed := strings.TrimSpace(typed)
		if trimmed == "" || trimmed == "{}" || trimmed == "null" {
			return true
		}
		var decoded any
		if errUnmarshal := json.Unmarshal([]byte(trimmed), &decoded); errUnmarshal != nil {
			return false
		}
		return isEmptySchemaValue(decoded)
	default:
		return false
	}
}

func isEmptySchemaObject(schemaObject map[string]any) bool {
	if schemaObject == nil {
		return true
	}
	if len(schemaObject) == 0 {
		return true
	}

	propertiesValue, hasProperties := schemaObject["properties"]
	if hasProperties {
		switch typedProperties := propertiesValue.(type) {
		case map[string]any:
			if len(typedProperties) > 0 {
				return false
			}
		case nil:
			// empty
		default:
			// non-object properties treat as non-empty to avoid overwriting odd schemas
			return false
		}
	}

	// required present with empty/missing properties is still empty/abnormal.
	// Only type=object (and maybe additionalProperties/description/$schema) counts as empty.
	for key, value := range schemaObject {
		switch key {
		case "type":
			typeString, okTypeString := value.(string)
			if okTypeString && strings.EqualFold(strings.TrimSpace(typeString), "object") {
				continue
			}
			if value != nil {
				return false
			}
		case "properties":
			continue
		case "required":
			continue
		case "additionalProperties":
			continue
		case "description", "$schema", "title":
			continue
		default:
			return false
		}
	}
	// properties missing or empty => empty schema
	return true
}

func appendUnique(values []string, addition string) []string {
	addition = strings.TrimSpace(addition)
	if addition == "" {
		return values
	}
	for _, existing := range values {
		if existing == addition {
			return values
		}
	}
	return append(values, addition)
}

func metadataString(metadata map[string]any, key string) string {
	if len(metadata) == 0 {
		return ""
	}
	raw, ok := metadata[key]
	if !ok || raw == nil {
		return ""
	}
	switch typed := raw.(type) {
	case string:
		return strings.TrimSpace(typed)
	case fmt.Stringer:
		return strings.TrimSpace(typed.String())
	default:
		return strings.TrimSpace(fmt.Sprint(typed))
	}
}
