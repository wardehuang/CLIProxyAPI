package main

const (
	pluginName    = "cpa-mcp-schema-patch"
	pluginVersion = "0.1.0"
)
