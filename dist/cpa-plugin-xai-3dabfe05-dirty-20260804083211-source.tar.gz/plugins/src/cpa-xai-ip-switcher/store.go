package main

import (
	"database/sql"
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	_ "github.com/mattn/go-sqlite3"
)

const (
	defaultDatabasePath             = "/opt/cli-proxy-api/plugin-data/cpa-xai-ip-switcher/ip-switcher.sqlite3"
	defaultWorkerCount              = 4
	defaultRefreshIntervalSeconds   = 30
	defaultKeepaliveWorkerCount     = 8
	defaultKeepaliveIntervalSeconds = 300
	defaultProbeRetryCount          = 3
	maxProbeWorkers                 = 64
	maxRefreshIntervalSeconds       = 3600
	maxKeepaliveIntervalSeconds     = 86400
	maxProbeRetryCount              = 10
	maxPluginLogs                   = 1000
	maxGroupedLogSets               = 10

	logLevelInfo  = "info"
	logLevelWarn  = "warn"
	logLevelError = "error"

	logCategoryGeneral        = "general"
	logCategoryBatchProbe     = "batch_probe"
	logCategoryKeepaliveProbe = "keepalive_probe"
	logStatusConnected        = "connected"
	logStatusProbing          = "probing"
	logStatusError            = "error"

	groupStatusRunning   = "running"
	groupStatusCompleted = "completed"

	statusHealthy          = "healthy"
	statusConnected        = "connected"
	statusCooldown         = "cooldown"
	statusProbing          = "probing"
	statusKeepaliveProbing = "keepalive_probing"
	statusUnprobed         = "unprobed"
	statusError            = "error"
	statusAll              = "all"

	probeKindInitial   = "initial"
	probeKindKeepalive = "keepalive"
)

type pluginSettings struct {
	WorkerCount              int
	RefreshIntervalSeconds   int
	KeepaliveWorkerCount     int
	KeepaliveIntervalSeconds int
	ProbeRetryCount          int
}

type proxyNode struct {
	ID                int64
	Name              string
	ProxyURL          string
	Host              string
	InputIP           string
	Port              int
	Protocol          string
	Domain            string
	BatchID           string
	Status            string
	InitialConnected  int64
	ProbeKind         string
	ProbeReturnStatus string
	KeepaliveRoundID  int64
	LatencyMs         int64
	EnteredAt         int64
	ProbeStartedAt    int64
	ProbeTime         int64
	ExitIP            string
	ErrorReason       string
	ErrorDetail       string
}

type ipBatch struct {
	ID                     string
	SequenceNumber         int64
	CreatedAt              int64
	TotalCount             int64
	DuplicateCount         int64
	InputErrorCount        int64
	CompletedCount         int64
	PendingCount           int64
	CandidateCount         int64
	InitialConnectedCount  int64
	RealtimeConnectedCount int64
}

type keepaliveRound struct {
	ID             int64
	SequenceNumber int64
	StartedAt      int64
	CompletedAt    int64
	Status         string
	CandidateCount int64
	SuccessCount   int64
	FailureCount   int64
}

type logGroup struct {
	ID             string
	SequenceNumber int64
	StartedAt      int64
	CompletedAt    int64
	Status         string
	LogCount       int64
	Category       string
}

type inputLineError struct {
	Line    int    `json:"line"`
	Message string `json:"message"`
}

type pluginLog struct {
	ID        int64
	CreatedAt int64
	Level     string
	Event     string
	Category  string
	GroupID   string
	LogStatus string
	NodeID    int64
	NodeName  string
	Message   string
	Detail    string
}

type ipStore struct {
	database *sql.DB
	path     string
}

func openIPStore(path string) (*ipStore, error) {
	resolvedPath, err := resolveDatabasePath(path)
	if err != nil {
		return nil, err
	}
	if err := os.MkdirAll(filepath.Dir(resolvedPath), 0o700); err != nil {
		return nil, fmt.Errorf("create database directory: %w", err)
	}

	database, err := sql.Open("sqlite3", resolvedPath+"?_busy_timeout=5000&_journal_mode=WAL&_foreign_keys=on")
	if err != nil {
		return nil, fmt.Errorf("open sqlite database: %w", err)
	}
	database.SetMaxOpenConns(1)
	database.SetMaxIdleConns(1)
	store := &ipStore{database: database, path: resolvedPath}
	if err := store.initialize(); err != nil {
		_ = database.Close()
		return nil, err
	}
	if err := os.Chmod(resolvedPath, 0o600); err != nil {
		_ = database.Close()
		return nil, fmt.Errorf("protect sqlite database: %w", err)
	}
	return store, nil
}

func resolveDatabasePath(path string) (string, error) {
	path = strings.TrimSpace(path)
	if path == "" {
		path = defaultDatabasePath
	}
	if filepath.IsAbs(path) {
		return filepath.Clean(path), nil
	}
	workingDirectory, err := os.Getwd()
	if err != nil {
		return "", fmt.Errorf("resolve database path: %w", err)
	}
	return filepath.Clean(filepath.Join(workingDirectory, path)), nil
}

func (store *ipStore) initialize() error {
	_, err := store.database.Exec(`
CREATE TABLE IF NOT EXISTS ip_nodes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    node_name TEXT NOT NULL,
    proxy_url TEXT NOT NULL UNIQUE,
    host TEXT NOT NULL,
    input_ip TEXT NOT NULL,
    port INTEGER NOT NULL,
    protocol TEXT NOT NULL,
    domain TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL,
    initial_connected INTEGER NOT NULL DEFAULT 0,
    latency_ms INTEGER NOT NULL DEFAULT 0,
    entered_at INTEGER NOT NULL,
    probe_started_at INTEGER NOT NULL DEFAULT 0,
    probe_kind TEXT NOT NULL DEFAULT '',
    probe_return_status TEXT NOT NULL DEFAULT '',
    keepalive_round_id INTEGER NOT NULL DEFAULT 0,
    probe_time INTEGER NOT NULL DEFAULT 0,
    exit_ip TEXT NOT NULL DEFAULT '',
    error_reason TEXT NOT NULL DEFAULT '',
    error_detail TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_ip_nodes_status_id ON ip_nodes(status, id);
CREATE TABLE IF NOT EXISTS ip_batches (
    batch_id TEXT PRIMARY KEY,
    sequence_number INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL,
    total_count INTEGER NOT NULL DEFAULT 0,
    duplicate_count INTEGER NOT NULL DEFAULT 0,
    input_error_count INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_ip_batches_created_at ON ip_batches(created_at DESC);
CREATE TABLE IF NOT EXISTS keepalive_rounds (
    round_id INTEGER PRIMARY KEY,
    sequence_number INTEGER NOT NULL,
    started_at INTEGER NOT NULL,
    completed_at INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'running',
    candidate_count INTEGER NOT NULL DEFAULT 0,
    success_count INTEGER NOT NULL DEFAULT 0,
    failure_count INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_keepalive_rounds_sequence ON keepalive_rounds(sequence_number DESC);
CREATE TABLE IF NOT EXISTS keepalive_round_nodes (
    round_id INTEGER NOT NULL,
    node_id INTEGER NOT NULL,
    PRIMARY KEY(round_id, node_id)
);
CREATE INDEX IF NOT EXISTS idx_keepalive_round_nodes_node_id ON keepalive_round_nodes(node_id);
CREATE TABLE IF NOT EXISTS plugin_settings (
    setting_key TEXT PRIMARY KEY,
    setting_value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS plugin_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at INTEGER NOT NULL,
    level TEXT NOT NULL,
    event TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT 'general',
    group_id TEXT NOT NULL DEFAULT '',
    log_status TEXT NOT NULL DEFAULT '',
    node_id INTEGER NOT NULL DEFAULT 0,
    node_name TEXT NOT NULL DEFAULT '',
    message TEXT NOT NULL,
    detail TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_plugin_logs_created_id ON plugin_logs(created_at DESC, id DESC);
INSERT OR IGNORE INTO plugin_settings(setting_key, setting_value) VALUES
    ('worker_count', '4'),
    ('refresh_interval_seconds', '30'),
    ('keepalive_worker_count', '8'),
    ('keepalive_interval_seconds', '300'),
    ('probe_retry_count', '3');
`)
	if err != nil {
		return fmt.Errorf("initialize sqlite database: %w", err)
	}
	if err := store.ensureProbeColumns(); err != nil {
		return err
	}
	if err := store.ensureBatchColumns(); err != nil {
		return err
	}
	if err := store.ensureBatchMetadata(); err != nil {
		return err
	}
	if err := store.ensureLogColumns(); err != nil {
		return err
	}
	if err := store.ensureInitialConnectedColumn(); err != nil {
		return err
	}
	if err := store.pruneStoredLogs(); err != nil {
		return err
	}
	_, err = store.database.Exec(`
UPDATE ip_nodes
SET status = CASE
        WHEN probe_kind = 'keepalive' AND probe_return_status IN ('healthy', 'connected', 'cooldown') THEN probe_return_status
        ELSE 'unprobed'
    END,
    probe_started_at = 0,
    probe_kind = '',
    probe_return_status = '',
    keepalive_round_id = 0
WHERE status IN ('probing', 'keepalive_probing');`)
	if err != nil {
		return fmt.Errorf("reset interrupted sqlite probes: %w", err)
	}
	if _, err := store.database.Exec(`DELETE FROM keepalive_round_nodes`); err != nil {
		return fmt.Errorf("clear interrupted sqlite keepalive round: %w", err)
	}
	if _, err := store.database.Exec(`
UPDATE keepalive_rounds
SET status = ?, completed_at = ?
WHERE status = ?`, groupStatusCompleted, time.Now().UnixMilli(), groupStatusRunning); err != nil {
		return fmt.Errorf("finish interrupted sqlite keepalive rounds: %w", err)
	}
	return nil
}

func (store *ipStore) ensureProbeColumns() error {
	rows, err := store.database.Query(`PRAGMA table_info(ip_nodes)`)
	if err != nil {
		return fmt.Errorf("inspect sqlite node columns: %w", err)
	}
	defer rows.Close()

	columns := make(map[string]bool)
	for rows.Next() {
		var (
			columnID       int
			columnName     string
			columnType     string
			notNull        int
			defaultValue   any
			primaryKeyFlag int
		)
		if err := rows.Scan(&columnID, &columnName, &columnType, &notNull, &defaultValue, &primaryKeyFlag); err != nil {
			return fmt.Errorf("scan sqlite node columns: %w", err)
		}
		columns[columnName] = true
	}
	if err := rows.Err(); err != nil {
		return fmt.Errorf("iterate sqlite node columns: %w", err)
	}
	if err := rows.Close(); err != nil {
		return fmt.Errorf("close sqlite node columns: %w", err)
	}
	for columnName, columnDefinition := range map[string]string{
		"probe_kind":          "TEXT NOT NULL DEFAULT ''",
		"probe_return_status": "TEXT NOT NULL DEFAULT ''",
		"keepalive_round_id":  "INTEGER NOT NULL DEFAULT 0",
	} {
		if columns[columnName] {
			continue
		}
		if _, err := store.database.Exec("ALTER TABLE ip_nodes ADD COLUMN " + columnName + " " + columnDefinition); err != nil {
			return fmt.Errorf("add sqlite node column %s: %w", columnName, err)
		}
	}
	return nil
}

func (store *ipStore) ensureInitialConnectedColumn() error {
	rows, err := store.database.Query(`PRAGMA table_info(ip_nodes)`)
	if err != nil {
		return fmt.Errorf("inspect sqlite initial connection column: %w", err)
	}
	columns := make(map[string]bool)
	for rows.Next() {
		var (
			columnID       int
			columnName     string
			columnType     string
			notNull        int
			defaultValue   any
			primaryKeyFlag int
		)
		if err := rows.Scan(&columnID, &columnName, &columnType, &notNull, &defaultValue, &primaryKeyFlag); err != nil {
			_ = rows.Close()
			return fmt.Errorf("scan sqlite initial connection column: %w", err)
		}
		columns[columnName] = true
	}
	if err := rows.Err(); err != nil {
		_ = rows.Close()
		return fmt.Errorf("iterate sqlite initial connection column: %w", err)
	}
	if err := rows.Close(); err != nil {
		return fmt.Errorf("close sqlite initial connection column: %w", err)
	}
	if !columns["initial_connected"] {
		if _, err := store.database.Exec("ALTER TABLE ip_nodes ADD COLUMN initial_connected INTEGER NOT NULL DEFAULT 0"); err != nil {
			return fmt.Errorf("add sqlite initial connection column: %w", err)
		}
	}
	if _, err := store.database.Exec(`
UPDATE ip_nodes
SET initial_connected = 1
WHERE initial_connected = 0
  AND id IN (
      SELECT node_id
      FROM plugin_logs
      WHERE category = ?
        AND event = 'probe.completed'
        AND log_status = ?
        AND node_id > 0
  )`, logCategoryBatchProbe, logStatusConnected); err != nil {
		return fmt.Errorf("backfill sqlite initial connected nodes: %w", err)
	}
	if _, err := store.database.Exec(`
UPDATE ip_nodes
SET initial_connected = 1
WHERE initial_connected = 0
  AND status IN (?, ?, ?)`, statusHealthy, statusConnected, statusCooldown); err != nil {
		return fmt.Errorf("infer sqlite initial connected nodes: %w", err)
	}
	return nil
}

func (store *ipStore) ensureBatchColumns() error {
	rows, err := store.database.Query(`PRAGMA table_info(ip_nodes)`)
	if err != nil {
		return fmt.Errorf("inspect sqlite batch columns: %w", err)
	}
	columns := make(map[string]bool)
	for rows.Next() {
		var (
			columnID       int
			columnName     string
			columnType     string
			notNull        int
			defaultValue   any
			primaryKeyFlag int
		)
		if err := rows.Scan(&columnID, &columnName, &columnType, &notNull, &defaultValue, &primaryKeyFlag); err != nil {
			_ = rows.Close()
			return fmt.Errorf("scan sqlite batch columns: %w", err)
		}
		columns[columnName] = true
	}
	if err := rows.Err(); err != nil {
		_ = rows.Close()
		return fmt.Errorf("iterate sqlite batch columns: %w", err)
	}
	if err := rows.Close(); err != nil {
		return fmt.Errorf("close sqlite batch columns: %w", err)
	}
	if !columns["batch_id"] {
		if _, err := store.database.Exec("ALTER TABLE ip_nodes ADD COLUMN batch_id TEXT NOT NULL DEFAULT ''"); err != nil {
			return fmt.Errorf("add sqlite batch column: %w", err)
		}
	}
	if _, err := store.database.Exec(`CREATE INDEX IF NOT EXISTS idx_ip_nodes_batch_id ON ip_nodes(batch_id)`); err != nil {
		return fmt.Errorf("create sqlite batch index: %w", err)
	}

	var legacyCount int64
	if err := store.database.QueryRow(`SELECT COUNT(*) FROM ip_nodes WHERE batch_id = ''`).Scan(&legacyCount); err != nil {
		return fmt.Errorf("count legacy sqlite nodes: %w", err)
	}
	if legacyCount == 0 {
		return nil
	}
	legacyCreatedAt := time.Now().UnixMilli()
	if err := store.database.QueryRow(`SELECT COALESCE(MIN(entered_at), ?) FROM ip_nodes WHERE batch_id = ''`, legacyCreatedAt).Scan(&legacyCreatedAt); err != nil {
		return fmt.Errorf("read legacy sqlite batch time: %w", err)
	}
	if _, err := store.database.Exec(`
INSERT OR IGNORE INTO ip_batches(batch_id, created_at, total_count)
VALUES ('legacy', ?, ?)`, legacyCreatedAt, legacyCount); err != nil {
		return fmt.Errorf("create legacy sqlite batch: %w", err)
	}
	if _, err := store.database.Exec(`UPDATE ip_nodes SET batch_id = 'legacy' WHERE batch_id = ''`); err != nil {
		return fmt.Errorf("assign legacy sqlite batch: %w", err)
	}
	if _, err := store.database.Exec(`
UPDATE ip_batches
SET total_count = (SELECT COUNT(*) FROM ip_nodes WHERE batch_id = 'legacy')
WHERE batch_id = 'legacy'`); err != nil {
		return fmt.Errorf("update legacy sqlite batch: %w", err)
	}
	return nil
}

func (store *ipStore) close() error {
	if store == nil || store.database == nil {
		return nil
	}
	return store.database.Close()
}

func newBatchID() string {
	return fmt.Sprintf("B%d", time.Now().UnixNano())
}

func (store *ipStore) insertNodes(nodes []proxyNode, inputErrorCount int) (batchID string, added, duplicates int, err error) {
	if len(nodes) == 0 {
		return "", 0, 0, nil
	}
	batchID = newBatchID()
	transaction, err := store.database.Begin()
	if err != nil {
		return batchID, 0, 0, fmt.Errorf("begin sqlite batch insert: %w", err)
	}
	defer func() {
		if err != nil {
			_ = transaction.Rollback()
		}
	}()

	createdAt := time.Now().UnixMilli()
	var sequenceNumber int64
	if err := transaction.QueryRow(`SELECT COALESCE(MAX(sequence_number), 0) + 1 FROM ip_batches`).Scan(&sequenceNumber); err != nil {
		return batchID, 0, 0, fmt.Errorf("read sqlite batch sequence: %w", err)
	}
	if _, err := transaction.Exec(`
INSERT INTO ip_batches(batch_id, sequence_number, created_at, input_error_count)
VALUES (?, ?, ?, ?)`, batchID, sequenceNumber, createdAt, inputErrorCount); err != nil {
		return batchID, 0, 0, fmt.Errorf("create sqlite batch: %w", err)
	}

	statement, err := transaction.Prepare(`
INSERT OR IGNORE INTO ip_nodes(
    node_name, proxy_url, host, input_ip, port, protocol, domain, batch_id, status, entered_at
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
	if err != nil {
		return batchID, 0, 0, fmt.Errorf("prepare sqlite insert: %w", err)
	}
	defer statement.Close()

	for _, node := range nodes {
		result, execErr := statement.Exec(
			node.Name,
			node.ProxyURL,
			node.Host,
			node.InputIP,
			node.Port,
			node.Protocol,
			node.Domain,
			batchID,
			statusUnprobed,
			createdAt,
		)
		if execErr != nil {
			return batchID, 0, 0, fmt.Errorf("insert sqlite node: %w", execErr)
		}
		rowsAffected, rowsErr := result.RowsAffected()
		if rowsErr != nil {
			return batchID, 0, 0, fmt.Errorf("read sqlite insert result: %w", rowsErr)
		}
		if rowsAffected == 0 {
			duplicates++
		} else {
			added++
		}
	}
	if _, err := transaction.Exec(`
UPDATE ip_batches SET total_count = ?, duplicate_count = ? WHERE batch_id = ?`, added, duplicates, batchID); err != nil {
		return batchID, 0, 0, fmt.Errorf("update sqlite batch: %w", err)
	}
	if err := transaction.Commit(); err != nil {
		return batchID, 0, 0, fmt.Errorf("commit sqlite batch insert: %w", err)
	}
	return batchID, added, duplicates, nil
}

func (store *ipStore) listNodes(status string) ([]proxyNode, error) {
	var (
		rows *sql.Rows
		err  error
	)
	if status == statusAll {
		rows, err = store.database.Query(`
SELECT id, node_name, batch_id, protocol, status, initial_connected, latency_ms, entered_at, probe_started_at, probe_time, exit_ip, error_reason, error_detail
FROM ip_nodes ORDER BY id DESC`)
	} else {
		rows, err = store.database.Query(`
SELECT id, node_name, batch_id, protocol, status, initial_connected, latency_ms, entered_at, probe_started_at, probe_time, exit_ip, error_reason, error_detail
FROM ip_nodes WHERE status = ? ORDER BY id DESC`, status)
	}
	if err != nil {
		return nil, fmt.Errorf("list sqlite nodes: %w", err)
	}
	defer rows.Close()

	items := make([]proxyNode, 0)
	for rows.Next() {
		var node proxyNode
		if err := rows.Scan(
			&node.ID,
			&node.Name,
			&node.BatchID,
			&node.Protocol,
			&node.Status,
			&node.InitialConnected,
			&node.LatencyMs,
			&node.EnteredAt,
			&node.ProbeStartedAt,
			&node.ProbeTime,
			&node.ExitIP,
			&node.ErrorReason,
			&node.ErrorDetail,
		); err != nil {
			return nil, fmt.Errorf("scan sqlite node: %w", err)
		}
		items = append(items, node)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate sqlite nodes: %w", err)
	}
	return items, nil
}

func (store *ipStore) listBatches() ([]ipBatch, error) {
	rows, err := store.database.Query(`
SELECT
    batches.batch_id,
    batches.sequence_number,
    batches.created_at,
    batches.duplicate_count,
    batches.input_error_count,
    COUNT(nodes.id),
    COALESCE(SUM(CASE
        WHEN nodes.id IS NOT NULL
         AND nodes.status NOT IN (?, ?)
         AND nodes.probe_kind <> ? THEN 1
        ELSE 0
    END), 0),
    COALESCE(SUM(CASE
        WHEN nodes.id IS NOT NULL
         AND (nodes.status IN (?, ?) OR nodes.probe_kind = ?) THEN 1
        ELSE 0
    END), 0),
    COALESCE(SUM(CASE
        WHEN nodes.status IN (?, ?, ?)
         AND NOT EXISTS (
             SELECT 1
             FROM ip_nodes AS batch_candidates
             WHERE batch_candidates.batch_id = batches.batch_id
               AND (batch_candidates.status IN (?, ?) OR batch_candidates.probe_kind = ?)
         ) THEN 1
        ELSE 0
    END), 0),
    COALESCE(SUM(CASE
        WHEN nodes.initial_connected = 1 THEN 1
        ELSE 0
    END), 0),
    COALESCE(SUM(CASE
        WHEN nodes.status IN (?, ?, ?) THEN 1
        ELSE 0
    END), 0)
FROM ip_batches AS batches
LEFT JOIN ip_nodes AS nodes ON nodes.batch_id = batches.batch_id
GROUP BY batches.batch_id, batches.sequence_number, batches.created_at, batches.duplicate_count, batches.input_error_count
ORDER BY batches.sequence_number DESC, batches.created_at DESC, batches.batch_id DESC`,
		statusUnprobed,
		statusProbing,
		probeKindInitial,
		statusUnprobed,
		statusProbing,
		probeKindInitial,
		statusHealthy,
		statusConnected,
		statusCooldown,
		statusUnprobed,
		statusProbing,
		probeKindInitial,
		statusHealthy,
		statusConnected,
		statusCooldown,
	)
	if err != nil {
		return nil, fmt.Errorf("list sqlite batches: %w", err)
	}
	defer rows.Close()

	items := make([]ipBatch, 0)
	for rows.Next() {
		var item ipBatch
		if err := rows.Scan(
			&item.ID,
			&item.SequenceNumber,
			&item.CreatedAt,
			&item.DuplicateCount,
			&item.InputErrorCount,
			&item.TotalCount,
			&item.CompletedCount,
			&item.PendingCount,
			&item.CandidateCount,
			&item.InitialConnectedCount,
			&item.RealtimeConnectedCount,
		); err != nil {
			return nil, fmt.Errorf("scan sqlite batch: %w", err)
		}
		items = append(items, item)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate sqlite batches: %w", err)
	}
	return items, nil
}

func (store *ipStore) listNodesByBatch(batchID string) ([]proxyNode, error) {
	rows, err := store.database.Query(`
SELECT id, node_name, batch_id, protocol, status, initial_connected, latency_ms, entered_at, probe_started_at, probe_time, exit_ip, error_reason, error_detail
FROM ip_nodes WHERE batch_id = ? ORDER BY id DESC`, batchID)
	if err != nil {
		return nil, fmt.Errorf("list sqlite batch nodes: %w", err)
	}
	defer rows.Close()

	items := make([]proxyNode, 0)
	for rows.Next() {
		var node proxyNode
		if err := rows.Scan(
			&node.ID,
			&node.Name,
			&node.BatchID,
			&node.Protocol,
			&node.Status,
			&node.InitialConnected,
			&node.LatencyMs,
			&node.EnteredAt,
			&node.ProbeStartedAt,
			&node.ProbeTime,
			&node.ExitIP,
			&node.ErrorReason,
			&node.ErrorDetail,
		); err != nil {
			return nil, fmt.Errorf("scan sqlite batch node: %w", err)
		}
		items = append(items, node)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate sqlite batch nodes: %w", err)
	}
	return items, nil
}

func (store *ipStore) deleteErrorNodes(errorReason string) (int64, error) {
	result, err := store.database.Exec(`
DELETE FROM ip_nodes WHERE status = ? AND error_reason = ?`, statusError, errorReason)
	if err != nil {
		return 0, fmt.Errorf("delete sqlite error nodes: %w", err)
	}
	deleted, err := result.RowsAffected()
	if err != nil {
		return 0, fmt.Errorf("read sqlite delete result: %w", err)
	}
	return deleted, nil
}

func (store *ipStore) getNode(id int64) (proxyNode, bool, error) {
	var node proxyNode
	err := store.database.QueryRow(`
SELECT id, node_name, batch_id, protocol, status, initial_connected, latency_ms, entered_at, probe_started_at, probe_time, exit_ip, error_reason, error_detail
FROM ip_nodes WHERE id = ?`, id).Scan(
		&node.ID,
		&node.Name,
		&node.BatchID,
		&node.Protocol,
		&node.Status,
		&node.InitialConnected,
		&node.LatencyMs,
		&node.EnteredAt,
		&node.ProbeStartedAt,
		&node.ProbeTime,
		&node.ExitIP,
		&node.ErrorReason,
		&node.ErrorDetail,
	)
	if err == sql.ErrNoRows {
		return proxyNode{}, false, nil
	}
	if err != nil {
		return proxyNode{}, false, fmt.Errorf("get sqlite node: %w", err)
	}
	return node, true, nil
}

func (store *ipStore) claimNext() (*proxyNode, error) {
	tx, err := store.database.Begin()
	if err != nil {
		return nil, fmt.Errorf("begin sqlite claim: %w", err)
	}
	defer tx.Rollback()

	var node proxyNode
	err = tx.QueryRow(`
SELECT id, node_name, proxy_url, host, input_ip, port, protocol, domain, batch_id
FROM ip_nodes WHERE status = ? ORDER BY id ASC LIMIT 1`, statusUnprobed).Scan(
		&node.ID,
		&node.Name,
		&node.ProxyURL,
		&node.Host,
		&node.InputIP,
		&node.Port,
		&node.Protocol,
		&node.Domain,
		&node.BatchID,
	)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, fmt.Errorf("select sqlite claim: %w", err)
	}

	startedAt := time.Now().UnixMilli()
	result, err := tx.Exec(`
UPDATE ip_nodes SET status = ?, probe_started_at = ?, probe_kind = ?, probe_return_status = '', keepalive_round_id = 0, error_reason = '', error_detail = ''
WHERE id = ? AND status = ?`, statusProbing, startedAt, probeKindInitial, node.ID, statusUnprobed)
	if err != nil {
		return nil, fmt.Errorf("update sqlite claim: %w", err)
	}
	rowsAffected, err := result.RowsAffected()
	if err != nil {
		return nil, fmt.Errorf("read sqlite claim result: %w", err)
	}
	if rowsAffected != 1 {
		return nil, fmt.Errorf("sqlite claim lost node %d", node.ID)
	}
	if err := tx.Commit(); err != nil {
		return nil, fmt.Errorf("commit sqlite claim: %w", err)
	}
	node.Status = statusProbing
	node.ProbeKind = probeKindInitial
	node.ProbeReturnStatus = ""
	node.ProbeStartedAt = startedAt
	_ = store.appendProbeLog(
		logCategoryBatchProbe,
		node.BatchID,
		logStatusProbing,
		logLevelInfo,
		"probe.started",
		node.ID,
		node.Name,
		"开始探测节点",
		fmt.Sprintf("协议 %s，目标 %s:%d", node.Protocol, node.Host, node.Port),
	)
	return &node, nil
}

func (store *ipStore) snapshotKeepaliveRound(roundID int64) (int64, error) {
	transaction, err := store.database.Begin()
	if err != nil {
		return 0, fmt.Errorf("begin sqlite keepalive snapshot: %w", err)
	}
	defer transaction.Rollback()

	if _, err := transaction.Exec(`DELETE FROM keepalive_round_nodes`); err != nil {
		return 0, fmt.Errorf("clear sqlite keepalive snapshot: %w", err)
	}
	result, err := transaction.Exec(`
INSERT INTO keepalive_round_nodes(round_id, node_id)
SELECT ?, candidates.id
FROM ip_nodes AS candidates
WHERE candidates.status IN (?, ?, ?)
  AND NOT EXISTS (
      SELECT 1
      FROM ip_nodes AS batch_nodes
      WHERE batch_nodes.batch_id = candidates.batch_id
        AND (batch_nodes.status IN (?, ?) OR batch_nodes.probe_kind = ?)
  )`, roundID, statusHealthy, statusConnected, statusCooldown, statusUnprobed, statusProbing, probeKindInitial)
	if err != nil {
		return 0, fmt.Errorf("snapshot sqlite keepalive candidates: %w", err)
	}
	candidateCount, err := result.RowsAffected()
	if err != nil {
		return 0, fmt.Errorf("read sqlite keepalive snapshot result: %w", err)
	}
	if err := transaction.Commit(); err != nil {
		return 0, fmt.Errorf("commit sqlite keepalive snapshot: %w", err)
	}
	return candidateCount, nil
}

func (store *ipStore) claimNextKeepalive(roundID int64) (*proxyNode, error) {
	transaction, err := store.database.Begin()
	if err != nil {
		return nil, fmt.Errorf("begin sqlite keepalive claim: %w", err)
	}
	defer transaction.Rollback()

	var node proxyNode
	var previousStatus string
	err = transaction.QueryRow(`
SELECT candidates.node_id, node_name, proxy_url, host, input_ip, port, protocol, domain, batch_id, status
FROM keepalive_round_nodes AS candidates
JOIN ip_nodes ON ip_nodes.id = candidates.node_id
WHERE candidates.round_id = ?
  AND status IN (?, ?, ?)
  AND keepalive_round_id <> ?
ORDER BY node_id ASC LIMIT 1`, roundID, statusHealthy, statusConnected, statusCooldown, roundID).Scan(
		&node.ID,
		&node.Name,
		&node.ProxyURL,
		&node.Host,
		&node.InputIP,
		&node.Port,
		&node.Protocol,
		&node.Domain,
		&node.BatchID,
		&previousStatus,
	)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, fmt.Errorf("select sqlite keepalive claim: %w", err)
	}

	startedAt := time.Now().UnixMilli()
	result, err := transaction.Exec(`
UPDATE ip_nodes
SET status = ?, probe_started_at = ?, probe_kind = ?, probe_return_status = ?, keepalive_round_id = ?, error_reason = '', error_detail = ''
WHERE id = ? AND status = ? AND keepalive_round_id <> ?`, statusKeepaliveProbing, startedAt, probeKindKeepalive, previousStatus, roundID, node.ID, previousStatus, roundID)
	if err != nil {
		return nil, fmt.Errorf("update sqlite keepalive claim: %w", err)
	}
	rowsAffected, err := result.RowsAffected()
	if err != nil {
		return nil, fmt.Errorf("read sqlite keepalive claim result: %w", err)
	}
	if rowsAffected != 1 {
		return nil, fmt.Errorf("sqlite keepalive claim lost node %d", node.ID)
	}
	if err := transaction.Commit(); err != nil {
		return nil, fmt.Errorf("commit sqlite keepalive claim: %w", err)
	}
	node.Status = statusKeepaliveProbing
	node.ProbeKind = probeKindKeepalive
	node.ProbeReturnStatus = previousStatus
	node.KeepaliveRoundID = roundID
	node.ProbeStartedAt = startedAt
	_ = store.appendProbeLog(
		logCategoryKeepaliveProbe,
		keepaliveGroupID(roundID),
		logStatusProbing,
		logLevelInfo,
		"keepalive.started",
		node.ID,
		node.Name,
		"开始保活探测节点",
		fmt.Sprintf("原状态 %s，协议 %s，目标 %s:%d", previousStatus, node.Protocol, node.Host, node.Port),
	)
	return &node, nil
}

func (store *ipStore) completeProbe(node proxyNode, result probeResult) error {
	probeTime := time.Now().UnixMilli()
	if node.ProbeKind == probeKindKeepalive {
		if result.PreserveStatus {
			_, err := store.database.Exec(`
UPDATE ip_nodes SET status = ?, latency_ms = ?, probe_time = ?, probe_started_at = 0,
    probe_kind = '', probe_return_status = '', keepalive_round_id = 0,
    exit_ip = CASE WHEN ? <> '' THEN ? ELSE exit_ip END,
    error_reason = '', error_detail = ?
WHERE id = ? AND status = ? AND probe_kind = ? AND keepalive_round_id = ?`, node.ProbeReturnStatus, result.LatencyMs, probeTime, result.ExitIP, result.ExitIP, result.Detail, node.ID, statusKeepaliveProbing, probeKindKeepalive, node.KeepaliveRoundID)
			if err != nil {
				return fmt.Errorf("save unconfirmed keepalive probe: %w", err)
			}
			_ = store.appendProbeLog(logCategoryKeepaliveProbe, keepaliveGroupID(node.KeepaliveRoundID), logStatusProbing, logLevelWarn, "keepalive.unconfirmed", node.ID, node.Name, "保活探测暂不可判定，节点保持原状态", formatProbeResultDetail(result))
			return nil
		}
		if result.Success {
			_, err := store.database.Exec(`
UPDATE ip_nodes SET status = ?, latency_ms = ?, probe_time = ?, probe_started_at = 0,
    probe_kind = '', probe_return_status = '', exit_ip = CASE WHEN ? <> '' THEN ? ELSE exit_ip END, error_reason = '', error_detail = ?
WHERE id = ? AND status = ? AND probe_kind = ? AND keepalive_round_id = ?`, node.ProbeReturnStatus, result.LatencyMs, probeTime, result.ExitIP, result.ExitIP, result.Detail, node.ID, statusKeepaliveProbing, probeKindKeepalive, node.KeepaliveRoundID)
			if err != nil {
				return fmt.Errorf("save keepalive success: %w", err)
			}
			_ = store.appendProbeLog(logCategoryKeepaliveProbe, keepaliveGroupID(node.KeepaliveRoundID), logStatusConnected, logLevelInfo, "keepalive.completed", node.ID, node.Name, "节点保活探测成功，状态保持不变", formatProbeResultDetail(result))
			return nil
		}
		_, err := store.database.Exec(`
UPDATE ip_nodes SET status = ?, latency_ms = ?, probe_time = ?, probe_started_at = 0,
    probe_kind = '', probe_return_status = '', keepalive_round_id = 0, exit_ip = CASE WHEN ? <> '' THEN ? ELSE exit_ip END, error_reason = ?, error_detail = ?
WHERE id = ? AND status = ? AND probe_kind = ? AND keepalive_round_id = ?`, statusError, result.LatencyMs, probeTime, result.ExitIP, result.ExitIP, result.Reason, result.Detail, node.ID, statusKeepaliveProbing, probeKindKeepalive, node.KeepaliveRoundID)
		if err != nil {
			return fmt.Errorf("save keepalive failure: %w", err)
		}
		_ = store.appendProbeLog(logCategoryKeepaliveProbe, keepaliveGroupID(node.KeepaliveRoundID), logStatusError, logLevelWarn, "keepalive.failed", node.ID, node.Name, fmt.Sprintf("保活探测失败：%s，节点归类为异常", result.Reason), formatProbeResultDetail(result))
		return nil
	}
	if result.Success {
		_, err := store.database.Exec(`
UPDATE ip_nodes SET status = ?, initial_connected = 1, latency_ms = ?, probe_time = ?, probe_started_at = 0,
    probe_kind = '', probe_return_status = '', exit_ip = ?, error_reason = '', error_detail = ?
WHERE id = ? AND status = ? AND probe_kind = ?`, statusConnected, result.LatencyMs, probeTime, result.ExitIP, result.Detail, node.ID, statusProbing, probeKindInitial)
		if err != nil {
			return fmt.Errorf("save connected probe: %w", err)
		}
		_ = store.appendProbeLog(logCategoryBatchProbe, node.BatchID, logStatusConnected, logLevelInfo, "probe.completed", node.ID, node.Name, "节点探测成功", formatProbeResultDetail(result))
		return nil
	}
	_, err := store.database.Exec(`
UPDATE ip_nodes SET status = ?, initial_connected = 0, latency_ms = ?, probe_time = ?, probe_started_at = 0,
    probe_kind = '', probe_return_status = '', exit_ip = ?, error_reason = ?, error_detail = ?
WHERE id = ? AND status = ? AND probe_kind = ?`, statusError, result.LatencyMs, probeTime, result.ExitIP, result.Reason, result.Detail, node.ID, statusProbing, probeKindInitial)
	if err != nil {
		return fmt.Errorf("save failed probe: %w", err)
	}
	_ = store.appendProbeLog(
		logCategoryBatchProbe,
		node.BatchID,
		logStatusError,
		logLevelWarn,
		"probe.failed",
		node.ID,
		node.Name,
		fmt.Sprintf("节点探测失败：%s", result.Reason),
		formatProbeResultDetail(result),
	)
	return nil
}

func (store *ipStore) resetProbe(node proxyNode) error {
	if node.ProbeKind == probeKindKeepalive {
		_, err := store.database.Exec(`
UPDATE ip_nodes SET status = ?, probe_started_at = 0, probe_kind = '', probe_return_status = ''
WHERE id = ? AND status = ? AND probe_kind = ? AND keepalive_round_id = ?`, node.ProbeReturnStatus, node.ID, statusKeepaliveProbing, probeKindKeepalive, node.KeepaliveRoundID)
		if err != nil {
			return fmt.Errorf("reset interrupted keepalive probe: %w", err)
		}
		return nil
	}
	_, err := store.database.Exec(`
UPDATE ip_nodes SET status = ?, probe_started_at = 0, probe_kind = '', probe_return_status = ''
WHERE id = ? AND status = ? AND probe_kind = ?`, statusUnprobed, node.ID, statusProbing, probeKindInitial)
	if err != nil {
		return fmt.Errorf("reset interrupted probe: %w", err)
	}
	return nil
}

func (store *ipStore) summary() (map[string]int64, error) {
	counts := map[string]int64{
		statusHealthy:          0,
		statusConnected:        0,
		statusCooldown:         0,
		statusProbing:          0,
		statusKeepaliveProbing: 0,
		statusUnprobed:         0,
		statusError:            0,
	}
	rows, err := store.database.Query(`SELECT status, COUNT(*) FROM ip_nodes GROUP BY status`)
	if err != nil {
		return nil, fmt.Errorf("summarize sqlite nodes: %w", err)
	}
	defer rows.Close()
	for rows.Next() {
		var status string
		var count int64
		if err := rows.Scan(&status, &count); err != nil {
			return nil, fmt.Errorf("scan sqlite summary: %w", err)
		}
		counts[status] = count
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate sqlite summary: %w", err)
	}
	return counts, nil
}

func (store *ipStore) settings() (pluginSettings, error) {
	settings := pluginSettings{
		WorkerCount:              defaultWorkerCount,
		RefreshIntervalSeconds:   defaultRefreshIntervalSeconds,
		KeepaliveWorkerCount:     defaultKeepaliveWorkerCount,
		KeepaliveIntervalSeconds: defaultKeepaliveIntervalSeconds,
		ProbeRetryCount:          defaultProbeRetryCount,
	}
	rows, err := store.database.Query(`
SELECT setting_key, setting_value
FROM plugin_settings
WHERE setting_key IN ('worker_count', 'refresh_interval_seconds', 'keepalive_worker_count', 'keepalive_interval_seconds', 'probe_retry_count')`)
	if err != nil {
		return pluginSettings{}, fmt.Errorf("read plugin settings: %w", err)
	}
	defer rows.Close()

	for rows.Next() {
		var settingKey, rawValue string
		if err := rows.Scan(&settingKey, &rawValue); err != nil {
			return pluginSettings{}, fmt.Errorf("scan plugin settings: %w", err)
		}
		value, err := strconv.Atoi(strings.TrimSpace(rawValue))
		if err != nil {
			continue
		}
		switch settingKey {
		case "worker_count":
			settings.WorkerCount = value
		case "refresh_interval_seconds":
			settings.RefreshIntervalSeconds = value
		case "keepalive_worker_count":
			settings.KeepaliveWorkerCount = value
		case "keepalive_interval_seconds":
			settings.KeepaliveIntervalSeconds = value
		case "probe_retry_count":
			settings.ProbeRetryCount = value
		}
	}
	if err := rows.Err(); err != nil {
		return pluginSettings{}, fmt.Errorf("iterate plugin settings: %w", err)
	}
	if err := rows.Close(); err != nil {
		return pluginSettings{}, fmt.Errorf("close plugin settings: %w", err)
	}
	if err := validatePluginSettings(settings); err != nil {
		settings = pluginSettings{
			WorkerCount:              defaultWorkerCount,
			RefreshIntervalSeconds:   defaultRefreshIntervalSeconds,
			KeepaliveWorkerCount:     defaultKeepaliveWorkerCount,
			KeepaliveIntervalSeconds: defaultKeepaliveIntervalSeconds,
			ProbeRetryCount:          defaultProbeRetryCount,
		}
		if err := store.setSettings(settings); err != nil {
			return pluginSettings{}, err
		}
	}
	return settings, nil
}

func (store *ipStore) setSettings(settings pluginSettings) error {
	if err := validatePluginSettings(settings); err != nil {
		return err
	}
	transaction, err := store.database.Begin()
	if err != nil {
		return fmt.Errorf("begin settings update: %w", err)
	}
	defer transaction.Rollback()

	settingsToSave := map[string]int{
		"worker_count":               settings.WorkerCount,
		"refresh_interval_seconds":   settings.RefreshIntervalSeconds,
		"keepalive_worker_count":     settings.KeepaliveWorkerCount,
		"keepalive_interval_seconds": settings.KeepaliveIntervalSeconds,
		"probe_retry_count":          settings.ProbeRetryCount,
	}
	for settingKey, settingValue := range settingsToSave {
		if _, err := transaction.Exec(`
INSERT INTO plugin_settings(setting_key, setting_value) VALUES (?, ?)
ON CONFLICT(setting_key) DO UPDATE SET setting_value = excluded.setting_value`, settingKey, strconv.Itoa(settingValue)); err != nil {
			return fmt.Errorf("save plugin setting %s: %w", settingKey, err)
		}
	}
	if err := transaction.Commit(); err != nil {
		return fmt.Errorf("commit settings update: %w", err)
	}
	return nil
}

func validatePluginSettings(settings pluginSettings) error {
	if settings.WorkerCount < 1 || settings.WorkerCount > maxProbeWorkers {
		return fmt.Errorf("worker count must be between 1 and %d", maxProbeWorkers)
	}
	if settings.RefreshIntervalSeconds < 5 || settings.RefreshIntervalSeconds > maxRefreshIntervalSeconds {
		return fmt.Errorf("refresh interval must be between 5 and %d seconds", maxRefreshIntervalSeconds)
	}
	if settings.KeepaliveWorkerCount < 1 || settings.KeepaliveWorkerCount > maxProbeWorkers {
		return fmt.Errorf("keepalive worker count must be between 1 and %d", maxProbeWorkers)
	}
	if settings.KeepaliveIntervalSeconds < 1 || settings.KeepaliveIntervalSeconds > maxKeepaliveIntervalSeconds {
		return fmt.Errorf("keepalive interval must be between 1 and %d seconds", maxKeepaliveIntervalSeconds)
	}
	if settings.ProbeRetryCount < 1 || settings.ProbeRetryCount > maxProbeRetryCount {
		return fmt.Errorf("probe retry count must be between 1 and %d", maxProbeRetryCount)
	}
	return nil
}
