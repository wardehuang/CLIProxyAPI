package main

import (
	"context"
	"net/http"
	"strings"
	"testing"

	"github.com/router-for-me/CLIProxyAPI/v7/sdk/pluginapi"
)

func TestIsCursorStyleUserAgent(t *testing.T) {
	if !isCursorStyleUserAgent("claude-cli/2.1.154 (external, cli)") {
		t.Fatal("expected cursor UA match")
	}
	if isCursorStyleUserAgent("claude-cli/2.1.220 (external, claude-vscode, agent-sdk/0.3.220)") {
		t.Fatal("official claude code UA must not match cursor style alone")
	}
	if isClaudeCodeOfficialUserAgent("claude-cli/2.1.154 (external, cli)") {
		t.Fatal("cursor UA must not be treated as official claude code")
	}
	if !isClaudeCodeOfficialUserAgent("claude-cli/2.1.220 (external, claude-vscode, agent-sdk/0.3.220)") {
		t.Fatal("expected official claude code UA")
	}
}

func TestBodyLooksLikeCursor(t *testing.T) {
	body := []byte(`{"system":[{"type":"text","text":"You operate in Cursor."}],"tools":[{"name":"Shell"},{"name":"AwaitShell"},{"name":"TodoWrite"},{"name":"ReadLints"},{"name":"SwitchMode"}]}`)
	if !bodyLooksLikeCursor(body) {
		t.Fatal("expected cursor body detection")
	}
	claudeCodeBody := []byte(`{"system":[{"type":"text","text":"You are Claude Code"}],"tools":[{"name":"Bash"},{"name":"Edit"}]}`)
	if bodyLooksLikeCursor(claudeCodeBody) {
		t.Fatal("claude code body must not look like cursor")
	}
}

func TestMergeAnthropicBeta(t *testing.T) {
	existing := "interleaved-thinking-2025-05-14,context-1m-2025-08-07"
	required := defaultClaudeCodeAnthropicBeta
	merged := mergeAnthropicBeta(existing, required)
	if !strings.Contains(merged, "claude-code-20250219") {
		t.Fatalf("missing claude-code beta: %s", merged)
	}
	if !strings.Contains(merged, "context-1m-2025-08-07") {
		t.Fatalf("should keep client-only beta: %s", merged)
	}
	if !strings.Contains(merged, "effort-2025-11-24") {
		t.Fatalf("missing effort beta: %s", merged)
	}
	if strings.Contains(merged, "oauth-") {
		t.Fatalf("oauth must be left to host: %s", merged)
	}
	// required token replaces older same-feature if present
	merged2 := mergeAnthropicBeta("interleaved-thinking-2024-01-01", "interleaved-thinking-2025-05-14")
	if merged2 != "interleaved-thinking-2025-05-14" {
		t.Fatalf("expected required feature replace, got %q", merged2)
	}
}

func TestRewriteCursorClaudeHeaders(t *testing.T) {
	configurePlugin(nil)
	headers := http.Header{}
	headers.Set("User-Agent", "claude-cli/2.1.154 (external, cli)")
	headers.Set("Anthropic-Beta", "interleaved-thinking-2025-05-14")
	headers.Set("X-Api-Key", "sk-test")

	body := []byte(`{"model":"claude-fable-5","system":[{"type":"text","text":"You operate in Cursor."}],"tools":[{"name":"Shell"},{"name":"AwaitShell"},{"name":"TodoWrite"},{"name":"ReadLints"},{"name":"SwitchMode"}]}`)
	resp := interceptRequestAfterAuth(context.Background(), pluginapi.RequestInterceptRequest{
		SourceFormat: "claude",
		ToFormat:     "claude",
		Model:        "claude-fable-5",
		Headers:      headers,
		Body:         body,
	}, "")
	if resp.Headers == nil {
		t.Fatal("expected header updates")
	}
	beta := resp.Headers.Get("Anthropic-Beta")
	if !strings.Contains(beta, "claude-code-20250219") {
		t.Fatalf("expected full beta rewrite, got %q", beta)
	}
	if !strings.Contains(beta, "interleaved-thinking-2025-05-14") {
		t.Fatalf("expected keep interleaved, got %q", beta)
	}
	if ua := resp.Headers.Get("User-Agent"); !strings.Contains(ua, "claude-vscode") {
		t.Fatalf("expected user-agent rewrite, got %q", ua)
	}
	if resp.Headers.Get("X-App") != "cli" {
		t.Fatalf("expected X-App=cli, got %q", resp.Headers.Get("X-App"))
	}
}

func TestSkipOfficialClaudeCode(t *testing.T) {
	configurePlugin(nil)
	headers := http.Header{}
	headers.Set("User-Agent", "claude-cli/2.1.220 (external, claude-vscode, agent-sdk/0.3.220)")
	headers.Set("Anthropic-Beta", defaultClaudeCodeAnthropicBeta)
	headers.Set("X-App", "cli")
	resp := interceptRequestAfterAuth(context.Background(), pluginapi.RequestInterceptRequest{
		SourceFormat: "claude",
		ToFormat:     "claude",
		Model:        "claude-fable-5",
		Headers:      headers,
		Body:         []byte(`{"model":"claude-fable-5","system":[{"type":"text","text":"You are Claude Code"}]}`),
	}, "")
	if resp.Headers != nil && len(resp.Headers) > 0 {
		t.Fatalf("official claude code must not be rewritten: %#v", resp.Headers)
	}
}

func TestPluginDisabled(t *testing.T) {
	configurePlugin([]byte("enabled: false\n"))
	defer configurePlugin(nil)
	headers := http.Header{}
	headers.Set("User-Agent", "claude-cli/2.1.154 (external, cli)")
	headers.Set("Anthropic-Beta", "interleaved-thinking-2025-05-14")
	resp := interceptRequestAfterAuth(context.Background(), pluginapi.RequestInterceptRequest{
		SourceFormat: "claude",
		ToFormat:     "claude",
		Model:        "claude-fable-5",
		Headers:      headers,
		Body:         []byte(`{"system":[{"text":"You operate in Cursor."}]}`),
	}, "")
	if resp.Headers != nil && len(resp.Headers) > 0 {
		t.Fatalf("disabled plugin must no-op: %#v", resp.Headers)
	}
}
