package main

import (
	"context"
	"net/http"
	"strings"

	"github.com/router-for-me/CLIProxyAPI/v7/sdk/pluginapi"
)

// Claude Code successful request (98e51d24) Anthropic-Beta list, without oauth-2025-04-20.
// Host applyClaudeHeaders appends oauth when missing for OAuth upstream.
const defaultClaudeCodeAnthropicBeta = "claude-code-20250219,interleaved-thinking-2025-05-14,thinking-token-count-2026-05-13,context-management-2025-06-27,prompt-caching-scope-2026-01-05,mid-conversation-system-2026-04-07,advisor-tool-2026-03-01,advanced-tool-use-2025-11-20,effort-2025-11-24,fallback-credit-2026-06-01"

// Matches host-stabilized Claude Code fingerprint observed on successful upstream.
const defaultClaudeCodeUserAgent = "claude-cli/2.1.220 (external, claude-vscode, agent-sdk/0.3.220)"

func interceptRequestBeforeAuth(ctx context.Context, req pluginapi.RequestInterceptRequest, hostCallbackID string) pluginapi.RequestInterceptResponse {
	// Host before-auth applies interceptor Headers as a full replacement when non-empty.
	// Only after-auth merges partial header updates. Do the rewrite there.
	_ = ctx
	_ = req
	_ = hostCallbackID
	return pluginapi.RequestInterceptResponse{}
}

func interceptRequestAfterAuth(ctx context.Context, req pluginapi.RequestInterceptRequest, hostCallbackID string) pluginapi.RequestInterceptResponse {
	return rewriteCursorClaudeHeaders(ctx, req.SourceFormat, req.ToFormat, req.Model, req.Headers, req.Body, hostCallbackID, "after_auth")
}

func rewriteCursorClaudeHeaders(
	ctx context.Context,
	sourceFormat string,
	toFormat string,
	model string,
	headers http.Header,
	body []byte,
	hostCallbackID string,
	stage string,
) pluginapi.RequestInterceptResponse {
	_ = ctx
	if !pluginEnabled() {
		logPluginDebug(hostCallbackID, "cursor claude headers skipped", map[string]any{
			"reason": "plugin_disabled",
			"stage":  stage,
		})
		return pluginapi.RequestInterceptResponse{}
	}
	if !isClaudeMessagesPath(sourceFormat, toFormat, model) {
		logPluginDebug(hostCallbackID, "cursor claude headers skipped", map[string]any{
			"reason":        "not_claude_messages",
			"stage":         stage,
			"source_format": sourceFormat,
			"to_format":     toFormat,
			"model":         model,
		})
		return pluginapi.RequestInterceptResponse{}
	}
	if !isCursorClient(headers, body) {
		logPluginDebug(hostCallbackID, "cursor claude headers skipped", map[string]any{
			"reason":        "not_cursor_client",
			"stage":         stage,
			"source_format": sourceFormat,
			"user_agent":    headerGet(headers, "User-Agent"),
		})
		return pluginapi.RequestInterceptResponse{}
	}

	originalBeta := headerGet(headers, "Anthropic-Beta")
	originalUserAgent := headerGet(headers, "User-Agent")
	mergedBeta := mergeAnthropicBeta(originalBeta, configuredAnthropicBeta())
	targetUserAgent := configuredUserAgent()

	updates := make(http.Header)
	changedKeys := make([]string, 0, 4)

	if !strings.EqualFold(strings.TrimSpace(originalBeta), strings.TrimSpace(mergedBeta)) {
		updates.Set("Anthropic-Beta", mergedBeta)
		changedKeys = append(changedKeys, "Anthropic-Beta")
	}
	if strings.TrimSpace(originalUserAgent) == "" || isCursorStyleUserAgent(originalUserAgent) {
		if !strings.EqualFold(strings.TrimSpace(originalUserAgent), strings.TrimSpace(targetUserAgent)) {
			updates.Set("User-Agent", targetUserAgent)
			changedKeys = append(changedKeys, "User-Agent")
		}
	}
	if headerGet(headers, "X-App") == "" {
		updates.Set("X-App", "cli")
		changedKeys = append(changedKeys, "X-App")
	}
	if headerGet(headers, "Anthropic-Version") == "" {
		updates.Set("Anthropic-Version", "2023-06-01")
		changedKeys = append(changedKeys, "Anthropic-Version")
	}

	if len(changedKeys) == 0 {
		logPluginDebug(hostCallbackID, "cursor claude headers skipped", map[string]any{
			"reason":         "already_complete",
			"stage":          stage,
			"anthropic_beta": originalBeta,
			"user_agent":     originalUserAgent,
		})
		return pluginapi.RequestInterceptResponse{}
	}

	logPluginInfo(hostCallbackID, "cursor claude headers rewritten", map[string]any{
		"stage":                   stage,
		"source_format":           sourceFormat,
		"to_format":               toFormat,
		"model":                   model,
		"changed_headers":         changedKeys,
		"original_anthropic_beta": originalBeta,
		"merged_anthropic_beta":   mergedBeta,
		"original_user_agent":     originalUserAgent,
		"merged_user_agent":       headerGetOr(updates, "User-Agent", originalUserAgent),
	})
	return pluginapi.RequestInterceptResponse{Headers: updates}
}

func isClaudeMessagesPath(sourceFormat, toFormat, model string) bool {
	source := strings.ToLower(strings.TrimSpace(sourceFormat))
	target := strings.ToLower(strings.TrimSpace(toFormat))
	modelLower := strings.ToLower(strings.TrimSpace(model))
	if source == "claude" || source == "anthropic" {
		return true
	}
	if target == "claude" || target == "anthropic" {
		return true
	}
	if strings.Contains(modelLower, "claude") {
		return true
	}
	return false
}

func isCursorClient(headers http.Header, body []byte) bool {
	userAgent := headerGet(headers, "User-Agent")
	if isClaudeCodeOfficialUserAgent(userAgent) {
		return false
	}
	if isCursorStyleUserAgent(userAgent) {
		return true
	}
	if bodyLooksLikeCursor(body) {
		return true
	}
	return false
}

func isClaudeCodeOfficialUserAgent(userAgent string) bool {
	lower := strings.ToLower(userAgent)
	if strings.Contains(lower, "claude-vscode") {
		return true
	}
	if strings.Contains(lower, "agent-sdk/") {
		return true
	}
	return false
}

func isCursorStyleUserAgent(userAgent string) bool {
	lower := strings.ToLower(strings.TrimSpace(userAgent))
	if lower == "" {
		return false
	}
	// Cursor Anthropic SDK UA observed: claude-cli/2.1.154 (external, cli)
	if strings.Contains(lower, "claude-cli/") && strings.Contains(lower, "(external, cli)") {
		return true
	}
	if strings.Contains(lower, "cursor") {
		return true
	}
	return false
}

func bodyLooksLikeCursor(body []byte) bool {
	if len(body) == 0 {
		return false
	}
	lower := strings.ToLower(string(body))
	markers := []string{
		"you operate in cursor",
		"powered by claude-fable",
		"<agent_transcripts>",
		"cursor rules",
		"agent transcripts (past chats)",
	}
	for _, marker := range markers {
		if strings.Contains(lower, marker) {
			return true
		}
	}
	// Cursor tool set is distinctive vs Claude Code.
	cursorTools := []string{`"shell"`, `"awaitshell"`, `"todowrite"`, `"readlints"`, `"switchmode"`}
	hit := 0
	for _, toolName := range cursorTools {
		if strings.Contains(lower, toolName) {
			hit++
		}
	}
	return hit >= 3
}

func mergeAnthropicBeta(existing string, required string) string {
	existingTokens := splitCommaList(existing)
	requiredTokens := splitCommaList(required)
	if len(requiredTokens) == 0 {
		return joinCommaList(existingTokens)
	}

	// Preserve client-provided order, then append missing required tokens.
	// Prefer the required token string when the same feature prefix already exists
	// with a different dated suffix (e.g. keep required claude-code-20250219).
	out := make([]string, 0, len(existingTokens)+len(requiredTokens))
	seenFeature := make(map[string]int) // feature key -> index in out

	appendOrReplace := func(token string, preferIncoming bool) {
		token = strings.TrimSpace(token)
		if token == "" {
			return
		}
		featureKey := betaFeatureKey(token)
		if index, exists := seenFeature[featureKey]; exists {
			if preferIncoming {
				out[index] = token
			}
			return
		}
		seenFeature[featureKey] = len(out)
		out = append(out, token)
	}

	for _, token := range existingTokens {
		// Do not keep oauth here; host injects oauth for OAuth auth.
		if strings.HasPrefix(strings.ToLower(token), "oauth-") {
			continue
		}
		appendOrReplace(token, false)
	}
	for _, token := range requiredTokens {
		if strings.HasPrefix(strings.ToLower(token), "oauth-") {
			continue
		}
		appendOrReplace(token, true)
	}
	return joinCommaList(out)
}

func betaFeatureKey(token string) string {
	token = strings.TrimSpace(strings.ToLower(token))
	if token == "" {
		return ""
	}
	// Prefer prefix before last dated segment: name-YYYY-MM-DD
	parts := strings.Split(token, "-")
	if len(parts) >= 4 {
		// last three parts look like year-month-day
		year := parts[len(parts)-3]
		month := parts[len(parts)-2]
		day := parts[len(parts)-1]
		if len(year) == 4 && len(month) == 2 && len(day) == 2 {
			return strings.Join(parts[:len(parts)-3], "-")
		}
	}
	return token
}

func splitCommaList(value string) []string {
	if strings.TrimSpace(value) == "" {
		return nil
	}
	parts := strings.Split(value, ",")
	out := make([]string, 0, len(parts))
	for _, part := range parts {
		trimmed := strings.TrimSpace(part)
		if trimmed == "" {
			continue
		}
		out = append(out, trimmed)
	}
	return out
}

func joinCommaList(values []string) string {
	if len(values) == 0 {
		return ""
	}
	return strings.Join(values, ",")
}

func headerGet(headers http.Header, key string) string {
	if headers == nil {
		return ""
	}
	return strings.TrimSpace(headers.Get(key))
}

func headerGetOr(headers http.Header, key, fallback string) string {
	if value := headerGet(headers, key); value != "" {
		return value
	}
	return fallback
}
