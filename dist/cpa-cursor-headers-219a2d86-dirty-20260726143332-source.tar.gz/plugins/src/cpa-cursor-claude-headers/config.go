package main

import (
	"bytes"
	"strings"
	"sync"

	"gopkg.in/yaml.v3"
)

type pluginConfig struct {
	Debug         bool   `json:"debug" yaml:"debug"`
	Enabled       *bool  `json:"enabled" yaml:"enabled"`
	AnthropicBeta string `json:"anthropic-beta" yaml:"anthropic-beta"`
	UserAgent     string `json:"user-agent" yaml:"user-agent"`
}

var pluginConfigState = struct {
	sync.RWMutex
	config pluginConfig
}{
	config: defaultPluginConfig(),
}

func defaultPluginConfig() pluginConfig {
	enabled := true
	return pluginConfig{
		Enabled:       &enabled,
		AnthropicBeta: defaultClaudeCodeAnthropicBeta,
		UserAgent:     defaultClaudeCodeUserAgent,
	}
}

func configurePlugin(configYAML []byte) {
	config := defaultPluginConfig()
	if len(bytes.TrimSpace(configYAML)) > 0 {
		var parsed pluginConfig
		if errUnmarshal := yaml.Unmarshal(configYAML, &parsed); errUnmarshal == nil {
			config.Debug = parsed.Debug
			if parsed.Enabled != nil {
				config.Enabled = parsed.Enabled
			}
			if trimmed := strings.TrimSpace(parsed.AnthropicBeta); trimmed != "" {
				config.AnthropicBeta = trimmed
			}
			if trimmed := strings.TrimSpace(parsed.UserAgent); trimmed != "" {
				config.UserAgent = trimmed
			}
		}
	}
	pluginConfigState.Lock()
	pluginConfigState.config = config
	pluginConfigState.Unlock()
}

func currentPluginConfig() pluginConfig {
	pluginConfigState.RLock()
	defer pluginConfigState.RUnlock()
	return pluginConfigState.config
}

func pluginDebugEnabled() bool {
	return currentPluginConfig().Debug
}

func pluginEnabled() bool {
	config := currentPluginConfig()
	if config.Enabled == nil {
		return true
	}
	return *config.Enabled
}

func configuredAnthropicBeta() string {
	config := currentPluginConfig()
	if trimmed := strings.TrimSpace(config.AnthropicBeta); trimmed != "" {
		return trimmed
	}
	return defaultClaudeCodeAnthropicBeta
}

func configuredUserAgent() string {
	config := currentPluginConfig()
	if trimmed := strings.TrimSpace(config.UserAgent); trimmed != "" {
		return trimmed
	}
	return defaultClaudeCodeUserAgent
}
