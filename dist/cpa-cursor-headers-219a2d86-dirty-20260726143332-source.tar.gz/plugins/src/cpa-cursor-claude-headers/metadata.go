package main

const (
	pluginName    = "cpa-cursor-claude-headers"
	pluginVersion = "0.1.0"
)
