# xAI 服务器巡检与条件巡检规则

> 本文记录 `CPA-Manager-Plus` 当前 wXAi 巡检源码的真实行为。
>
> 最后核对日期：2026-07-24
>
> 权威实现目录：`CPA-Manager-Plus/apps/manager-server/internal/service/wxaiinspection`

## 1. 文档维护要求

修改以下任一行为时，必须同步更新本文：

- 服务器巡检、条件巡检、手动刷新的候选与冷却规则。
- access token JWT 解码、`bot_flag_source`、billing、credits、responses 的请求顺序和分类。
- HTTP 状态、额度状态与 priority 的映射。
- `UNKNOWN/FREE/SUPER` 类型识别与持久化。
- timeout、重试、CPA `proxy-url`、结果落库和 priority 恢复。
- xAI 业务请求 HTTP 429 的条件巡检即时触发、SUPER 冷却时间补查、并发和 run 复用规则。

若本文与源码冲突，以源码为准，并立即修正文档。

## 2. priority

| priority | 含义 | 巡检处理 |
|---:|---|---|
| `-1` | 明确额度耗尽 | 冷却结束前所有巡检跳过；冷却到期后服务器巡检和手动刷新可重新检查 |
| `-2` | 普通账号异常、billing/credits 异常、请求异常或 JWT 解码异常 | 服务器巡检继续检查；条件巡检可检查 |
| `-3` | 旧版托管异常值 | 服务器巡检继续检查；条件巡检可检查 |
| `-4` | HTTP 401 | 服务器巡检继续检查；条件巡检可检查 |
| `-5` | 停用 | 所有巡检跳过 xAI 网络请求 |
| `-6` | access token JWT 中存在非空 `bot_flag_source` | 服务器、条件、手动刷新和业务 429 快速路径全部跳过，不自动恢复或覆盖 |
| 其他值或空值 | 正常账号 | 按候选规则检查 |

健康后的托管 priority 恢复目标：

- `SUPER`：恢复为 `3`。
- `FREE` 且账号邮箱域名大小写不敏感地等于 `gmail.com`：恢复为 `2`。
- 其他 `FREE`：恢复为 `1`。
- `UNKNOWN` 不允许执行健康恢复；必须先通过普通 billing 判定为 `FREE` 或 `SUPER`。
- 只有 `-1/-2/-3/-4` 或仍匹配现存 adjustment 的账号进入恢复流程；普通正 priority 不主动归一化。
- `-6` 不属于可恢复 priority。

## 3. 账号类型持久化

账号类型允许：

- `UNKNOWN`
- `FREE`
- `SUPER`

类型保存于独立表 `wxai_account_profiles`，以 `account_key` 为主键。没有 profile、空类型和 `UNKNOWN` 都表示需要重新判型。

类型判定规则：

1. 下载 auth JSON 并读取 `access_token`。
2. 在任何 xAI HTTP 请求前解码 access token JWT payload，检查 `bot_flag_source`。
3. 已知 `FREE` 不调用普通 billing；使用 credits 完成健康检查。
4. 类型为空或 `UNKNOWN` 时调用 `GET /v1/billing` 判型。
5. 普通 billing 的 `monthlyLimit > 0` 判为 `SUPER`，否则判为 `FREE`，随后持久化。
6. 已知 `SUPER` 每轮仍调用普通 billing 刷新月额度，但不使用该次响应重新降级账号类型。
7. UNKNOWN 判型所需的普通 billing 请求、HTTP 响应或 JSON 解析异常时，账号类型持久化为 `UNKNOWN`，账号异常，priority 按响应分类设为 `-2/-4/-1`；后续可参与巡检时再次调用普通 billing。
8. 明确额度耗尽的实际业务请求保持原 FREE 快速路径：类型为空或 `UNKNOWN` 时直接持久化为 `FREE`。

## 4. `bot_flag_source`

`bot_flag_source` 位于 access token JWT payload，不读取 auth JSON 顶层同名字段。

处理顺序和语义：

1. `access_token` 缺失：账号异常，priority `-2`，停止后续流程。
2. access token 不是 JWT、payload Base64URL 解码失败、payload 不是 JSON object：账号异常，priority `-2`，记录详细解码原因，停止后续流程。
3. payload 不存在 `bot_flag_source`：继续巡检。
4. `bot_flag_source=null` 或空字符串：不判为 bot，继续巡检。
5. 其他值均判为 bot，包括 `false`、`0`、非空字符串、array 和 object。
6. bot 账号记录规范化后的 `bot_flag_source` JSON 值，priority 直接设为 `-6`，删除已有 priority adjustment，停止本次后续流程。
7. 后续服务器巡检、条件巡检、手动刷新和业务 429 快速路径均跳过 `-6`，不再下载 auth JSON，也不发送 billing、credits 或 responses 请求。

## 5. 服务器巡检健康链路

所有实际参与巡检的账号使用同一套新链路；条件巡检和手动刷新选中账号后也复用该链路。

执行顺序：

1. 下载 auth JSON。
2. 读取 `access_token`。
3. 解码 JWT 并处理 `bot_flag_source`。
4. 类型为空或 `UNKNOWN` 时调用普通 billing 判定并落盘类型。
5. 根据最终类型和当前 priority 选择请求：
   - `FREE` 且当前 priority 为 `-1`：只调用 `POST /v1/responses`。
   - 其他 `FREE`：通过 CPA Management `POST /v0/management/api-call` 代理执行 `GET /v1/billing?format=credits`。
   - 本轮由 `UNKNOWN` 判为 `SUPER`：复用已完成的普通 billing，再通过 CPA `api-call` 调用 credits。
   - 已知 `SUPER`：并发发起两次 CPA `api-call`，分别执行普通 billing 和 credits，获取月额度与周额度。
6. `SUPER` 的普通 billing 和 credits 任一异常，本轮均按统一 HTTP 映射判为异常；两者都正常才恢复托管 priority。
7. 健康请求正常后，按账号类型和邮箱恢复托管 priority。
8. 保存结果、状态详情、两类原始 HTTP 响应和额度窗口。

不再调用 `POST /v1/chat/completions`，也不存在 chat fallback。

### 5.1 普通 billing 判型

- Manager Server 调用 CPA Management `POST /v0/management/api-call`，由 CPA 使用目标账号 `authIndex` 代理执行上游请求。
- 上游 Method：`GET`
- 上游 URL：`https://cli-chat-proxy.grok.com/v1/billing`
- 类型为空或 `UNKNOWN` 时用于判型；已知 `SUPER` 时用于每轮刷新月额度。
- UNKNOWN 判型时，`monthlyLimit > 0` 判为 `SUPER`，`monthlyLimit <= 0` 或字段缺失判为 `FREE`。
- 已知 `SUPER` 的普通 billing 结果只刷新 `monthlyLimit`、`used`、月重置时间和月额度窗口，不重新判型。
- UNKNOWN 判型的普通 billing 异常后不继续 credits 或 responses，并保持类型 `UNKNOWN`。
- 已知 `SUPER` 的普通 billing 与 credits 并发执行；普通 billing HTTP 或 JSON 异常时本轮账号异常。

### 5.2 credits 健康检查

- Manager Server 调用 CPA Management `POST /v0/management/api-call`，由 CPA 使用目标账号 `authIndex` 代理执行上游请求。
- 上游 Method：`GET`
- 上游 URL：`https://cli-chat-proxy.grok.com/v1/billing?format=credits`
- 用于所有 `SUPER` 和非 `-1` 的 `FREE`。
- HTTP 2xx 且 JSON 可解析：账号健康，可恢复 priority。
- 仅当响应明确包含 `creditUsagePercent`、有效 `currentPeriod.type` 和有效结束时间时生成 credits 额度窗口；不得把缺失的 `creditUsagePercent` 补为 `0`。
- `creditUsagePercent` 按已用百分比保存，只用于额度展示，不以百分比判断额度耗尽。
- `currentPeriod.end` 或 `billingPeriodEnd` 即使存在，也只用于恢复时间；缺少 `creditUsagePercent` 时不能据此生成额度窗口。
- 监控页不按账号类型强制隐藏额度；没有合法额度窗口的账号才显示“暂无额度”。
- 监控页显示剩余百分比，即 `100 - usedPercent`；例如已用 `2%` 显示剩余 `98%`。
- 额度条与 Codex 页面保持一致，按剩余比例使用动态渐变：`>40%` 青绿、`21%-40%` 黄绿到橙、`6%-20%` 黄到橙、`<=5%` 粉红到红。
- 同时存在周、月窗口时固定先显示周限额，再显示月限额。
- `currentPeriod.end` 优先于 `billingPeriodEnd` 作为额度窗口结束时间。
- HTTP 2xx 但 JSON 无法解析：请求异常，priority `-2`。
- 404、5xx、网络错误、timeout 均直接设为 `-2`，不执行 chat fallback。

普通 billing 和 credits 共用认证文件页面的固定客户端标识：

- `x-grok-client-version: 0.2.101`
- `User-Agent: grok-pager/0.2.101 grok-shell/0.2.101 (macos; aarch64)`
- `X-XAI-Token-Auth: xai-grok-cli`
- `Accept: */*`
- auth JSON 的 `sub/subject/user_id/userId` 存在时发送 `x-userid`；否则使用账号列表中的 `accountId`，两者都为空时不发送。
- 不再发送旧巡检专用的 `x-grok-client-identifier`、`x-grok-client-surface` 和 `x-grok-client-name`。

### 5.3 FREE `-1` 恢复探测

冷却到期、可再次参与服务器巡检或手动刷新的 `FREE priority=-1` 账号：

- Method：`POST`
- URL：`https://cli-chat-proxy.grok.com/v1/responses`
- Body：`{"model":"grok-4.5","input":"ping","stream":false}`
- 不调用 credits。
- 不调用 chat completions。
- responses 正常才恢复 priority；异常按统一 HTTP 映射继续保持或调整异常 priority。

responses headers：

- `X-XAI-Token-Auth: xai-grok-cli`
- `x-grok-client-version`：每轮从 CPA `GET /v0/management/xai-client-version` 读取。
- `User-Agent: xai-grok-workspace/<xaiClientVersionValue>`。

## 6. HTTP 与请求异常映射

普通 billing、credits 和 FREE `-1` responses 的结果统一分类：

- 普通 billing/credits：HTTP 2xx 且对应 JSON 可解析时健康。
- FREE `-1` responses：HTTP 2xx 即健康，不解析成功响应 body。
- HTTP 401：账号异常，priority `-4`。
- 错误 code/message 包含 `free-usage-exhausted`、`used all the included free usage` 或 `included free usage has been exhausted`：额度耗尽，priority `-1`。
- 其他 HTTP 429：账号异常，priority `-2`。
- HTTP 402/403：账号异常，priority `-2`。
- HTTP 404：账号异常，priority `-2`。
- HTTP 5xx：账号异常，priority `-2`。
- 其他非 2xx HTTP：账号异常，priority `-2`。
- timeout、网络错误、原始响应落库失败、JSON 解析失败：请求异常，priority `-2`。

仅明确额度耗尽文案可判定 `isQuota=true`。billing/credits 百分比和普通 HTTP 429 均不能单独判定额度耗尽。

## 7. timeout 与重试

每个 xAI HTTP 请求使用巡检配置中的单次 timeout。发生 timeout 时：

1. 等待 400ms。
2. 原请求重试一次。
3. 非 timeout 网络错误不重试。
4. 上下文已取消时不重试。

该规则应用于普通 billing、credits 和 responses。

## 8. 额度冷却

额度耗尽的恢复时间保存于 `wxai_priority_adjustments.recover_at_ms`。

巡检 HTTP 响应恢复时间计算顺序：

1. `Retry-After` header。
2. `X-RateLimit-Reset` 或 `X-Rate-Limit-Reset` header。
3. JSON 中的 `retry_after`、`retryAfter`、`retry_after_ms`、`reset_at`、`resetAt`、`resets_at`、`recovery_time`、`recover_at` 等字段。
4. 有有效恢复时间：冷却至恢复时间加 1 分钟。
5. 没有有效恢复时间：冷却至当前时间加 24 小时再加 1 分钟。

冷却期间：

- 存在尚未到期、目标 priority 为 `-1` 的 adjustment。
- priority patch 失败时回滚本次 adjustment，不形成假冷却。
- 服务器巡检跳过。
- 条件巡检在原候选算法完成后过滤；条件候选本身也排除 `priority=-1`。
- 手动刷新跳过。
- 不下载 auth JSON，不调用 billing、credits 或 responses。
- priority 保持当前值。
- 服务器新 run 复用上一轮状态和额度数据，并标记 `skipped`。
- `/v0/management/wxai-inspection/latest` 返回 adjustment 的 `recoverAtMs`。

冷却到期后：

- `FREE -1` 使用 responses 恢复探测。
- `SUPER -1` 与其他已知 SUPER 相同，并发调用普通 billing 和 credits。
- `UNKNOWN -1` 先普通 billing 判型，再按判定类型选择 endpoint。

## 9. 实际业务请求 HTTP 429

### 9.1 明确额度耗尽

当 usage event 的 `fail_body`、`raw_json` 或 `fail_summary` 可明确识别额度耗尽文案时，进入请求额度落盘快速路径：

1. 不查询最近 10 分钟条件候选，不创建新服务器 run。
2. 通过 CPA Management API 读取 xAI auth file 列表，按 `fileName + authIndex`、唯一 `fileName`、唯一 `authIndex` 匹配账号。
3. `priority=-6` 直接跳过，不覆盖为 `-1`。
4. 类型为空或 `UNKNOWN` 时保持原 FREE 逻辑，直接落盘为 `FREE`。
5. `FREE` 复用原响应 header/body 恢复时间；没有有效恢复时间时默认 24 小时加 1 分钟，不发送额外 xAI 请求。
6. `SUPER` 先使用原响应 header/body 恢复时间；若缺失、为空、无效或已过期，则下载该账号 auth JSON，并通过 CPA Management `POST /v0/management/api-call` 以目标 `authIndex` 调用 `GET /v1/billing?format=credits`。
7. SUPER credits 正常时，从 `currentPeriod.end` 或 `billingPeriodEnd` 取得恢复时间；仍取不到、credits 请求异常或解析异常时，默认 24 小时加 1 分钟。
8. 最终 priority 调整为 `-1`，写入 `wxai_priority_adjustments`。
9. 存在最近非 `running` run 时，复用该 run 写结果、状态详情、SUPER credits 原始响应和 `【wXAi 请求额度落盘】` 日志。
10. 没有可复用 run 时仍修改 priority/profile/adjustment；不伪造巡检结果或数据库 run 日志。worker 进程日志仍记录账号类型、恢复来源、credits 是否调用、credits 恢复时间和错误。
11. 明确额度事件不触发条件巡检；账号无法安全匹配或 priority patch 失败时记录错误，也不退回到普通探测。

SUPER 业务 429 的 credits 补查不读取 `xai-client-version`；通过 CPA `api-call` 使用第 5.2 节的固定 billing headers、`x-userid` 和 CPA credential proxy 选择规则。

### 9.2 普通 HTTP 429

无法明确判定额度耗尽的普通 xAI HTTP 429：

- 不直接修改 priority。
- 立即触发一次条件巡检。
- 条件巡检仍按最近 10 分钟全部候选重新筛选，不只检查报错账号。
- 选中账号执行本文第 4、5、6 节的新健康链路。

### 9.3 quota-auto-disable

若自动化设置中的 `quotaCooldownEnabled` 同时开启，同一明确额度 usage event 还会独立进入既有 `quota-auto-disable` 流程：

- 按 auth file 保存 CPAMP 所有权并临时设置 `disabled=true`。
- 24 小时后仅恢复由 CPAMP 本次自动停用的文件。
- 该流程与 wXAi priority `-1` adjustment 独立，不替代请求额度落盘快速路径。

## 10. 服务器巡检

服务器巡检创建新 `wxai_inspection_runs`。xAI 业务请求 HTTP 429 不创建服务器巡检 run。

定时触发规则：

1. Worker 每 30 秒检查一次配置。
2. `time_points` 模式按配置时区计算不晚于当前时刻的最近一个时间点，使用该时间点生成 `triggerKey`，格式为 `YYYY-MM-DD HH:mm`。
3. 若到点时手动巡检或条件巡检占用全局巡检锁，本次 tick 跳过；锁释放后的后续 tick 仍检查最近应执行时间点并补跑。
4. 若存在同一 `scheduled + triggerKey` 的 run，无论成功或失败，都不重复执行。
5. 若跨过多个时间点，只补跑最近一个应执行时间点。
6. `interval` 模式按最近一次定时 run 开始时间和 `intervalMinutes` 判断是否到期。

候选规则：

1. `priority=-5`：停用集合，不执行 xAI 请求。
2. `priority=-6`：bot 集合，不执行 xAI 请求。
3. 额度冷却未结束：冷却集合，不执行 xAI 请求。
4. 其余 xAI 账号全部参与，不再按普通或托管 positive priority 区分。

服务器执行顺序：

1. 读取 CPA `proxy-url` 和核心 `xaiClientVersionValue`，创建本轮共享 xAI HTTP client。
2. 并发下载 auth JSON。
3. JWT bot 判定。
4. UNKNOWN 普通 billing 判型。
5. FREE 执行 credits 或 `-1` responses；已知 SUPER 并发执行普通 billing 和 credits。
6. 根据结果调整或恢复 priority。
7. 保存结果、状态详情、普通 billing/credits/responses 原始 HTTP 响应和窗口花费。

服务器账号并发使用 `settings.Workers`，小于等于 0 时按 1；默认 4。

## 11. 条件巡检

触发、候选和 run 复用规则不变；选中账号后的单账号健康链路改为本文第 4、5、6 节。

触发来源：

1. 条件巡检 worker 启动后立即检查一次，之后每 30 秒检查一次。
2. collector 新收到 `failed=true`、`fail_status_code=429`、provider 归一化为 `xai`，且不能明确判定额度耗尽的 usage event 时立即触发一次。

同一批普通 429 只触发一次。即时触发和 30 秒 worker 共用条件 worker 本地运行锁，以及 wXAi 服务全局运行锁；已有条件、服务器或手动巡检运行时，本次普通 429 触发跳过，不排队、不重试。

条件候选算法：

- 查询最近 10 分钟 `usage_events`。
- `calls > 0`。
- provider 归一化为 `xai`。
- 匹配顺序：`accountKey`、`fileName + authIndex`、`provider + accountID`、唯一 `fileName`、唯一 `authIndex`。
- 排除 `priority=-5`、`priority=-6` 和 `priority=-1`。
- 其他 priority 可进入。
- 同一账号去重，候选原因仍为 `active_recent`。

候选生成后，再统一过滤仍处于额度冷却期的账号。条件巡检复用最近一次非 `running` run，不创建新 run。

明确额度快速路径串行处理，并复用服务全局运行锁。若已有其他巡检运行，每 250ms 等待锁释放。一个批次同时存在明确额度事件和普通 429 时，先完成明确额度落盘，再触发一次普通条件巡检。

## 12. 手动刷新

手动刷新只针对指定账号：

- `priority=-5`：保持停用，不执行网络请求。
- `priority=-6`：保持 bot 异常，不执行网络请求，不允许手动刷新恢复。
- 额度冷却未结束：保持额度耗尽状态，不执行网络请求。
- 其他账号执行与服务器巡检相同的 JWT、判型、普通 billing/credits/responses 和恢复逻辑。

手动刷新复用最近 run，不创建新 run。

## 13. CPA api-call、proxy-url 与 client version

服务器巡检、条件巡检和手动刷新在有实际候选时仍初始化仅供 responses 使用的共享 client：

1. `GET /v0/management/config` 读取全局 `proxy-url`。
2. `GET /v0/management/xai-client-version` 读取核心 `xaiClientVersionValue`。
3. 两项成功后创建只供 `POST /v1/responses` 使用的共享 xAI HTTP client。

即使本轮候选最终只调用 billing/credits，也仍执行上述初始化。读取失败或全局 `proxy-url` 非法时本轮 fail-fast，不发送 billing、credits 或 responses。

billing/credits 改走 CPA Management `POST /v0/management/api-call`：

- 传入目标账号 `authIndex`。
- `Authorization: Bearer $TOKEN$` 中的 `$TOKEN$` 由 CPA 使用该 credential 的当前 token 替换。
- CPA 的代理选择顺序为 credential `proxy_url`、匹配 provider API 配置的代理、全局 `proxy-url`、直连。
- Manager Server 不自行复制 credential proxy 选择逻辑。
- CPA `api-call` 返回的上游 `status_code`、headers 和 body 再进入巡检分类与原始响应落库。

responses 共享 client 的全局代理规则保持不变：

- 全局 `proxy-url` 非空时设置该代理。
- `socks5://` 和 `socks5h://` 使用 SOCKS5 Dialer，兼容标准格式和现网旧格式。
- `http://` 和 `https://` 使用 `http.Transport.Proxy`。
- 全局 `proxy-url` 为空时直连，不读取进程环境代理。
- CPA auth-files 下载、priority patch 和 billing/credits `api-call` 直接访问 CPA Management API，不经过 responses 共享 client。
- `wXAi 请求代理已配置` 日志只代表 responses 共享 client 的脱敏全局代理摘要，不代表 billing/credits 最终选择的代理。

SUPER 业务 429 的 credits 补查也走 CPA `api-call`，且不读取 `xai-client-version`。

## 14. 落库、日志与原始响应

- 普通 billing、credits、responses 的 HTTP 响应追加保存到 `wxai_inspection_http_responses`。
- UNKNOWN 判型普通 billing、SUPER billing/credits 和 SUPER 业务 429 credits 补查写请求诊断日志；普通 FREE credits 不额外写该诊断，避免全量巡检产生大量日志。
- 请求诊断包含账号键、文件名、`authIndex`、请求阶段、是否发送 `x-userid`、固定 client version/User-Agent、timeout 和重试次数；不记录 token 或 `x-userid` 原值。
- 成功响应写字段级诊断日志：上游状态、body 大小、JSON/config 是否存在、字段名列表、普通 billing 的 monthlyLimit/used/周期字段、credits 的 `creditUsagePercent`/`currentPeriod`/周期字段，以及该响应是否满足额度窗口生成条件；不写完整响应 body。
- 诊断范围内的请求失败写 warning 日志，包含请求阶段、账号定位信息、attempt、错误和是否 timeout。
- timeout 或网络错误没有 HTTP 响应，不写原始响应记录。
- 请求额度快速路径的原业务响应不伪装成巡检 HTTP 响应。
- SUPER 业务 429 额外调用 credits 时，只有存在可复用 run 才保存该 credits HTTP 响应；run 不存在时仍完成 priority/profile/adjustment，并通过 worker 进程日志留痕。
- response headers 会脱敏：`Authorization`、`Proxy-Authorization`、`Set-Cookie`、`Set-Cookie2` 替换为 `[REDACTED]`。
- billing/credits/JWT 异常结果保存 `errorKind` 和详细 `errorDetail`。
- bot 结果和日志保存规范化后的 `bot_flag_source` 值。
- 服务器新 run 对 `-5`、`-6` 和冷却账号复用上一轮状态；`-6` 保留已有 bot 详细原因并标记 skipped。
- priority adjustment 先落库再 patch；patch 失败回滚 adjustment。
- bot `-6` 直接 patch 并删除 adjustment，不设置自动恢复时间。
