package main

import (
	"context"
	"fmt"
	"sync"
)

var pluginRuntime = &runtimeController{}

type runtimeController struct {
	mutex        sync.RWMutex
	store        *ipStore
	workerCancel context.CancelFunc
	workerGroup  sync.WaitGroup
}

func (controller *runtimeController) configure(config pluginConfig) error {
	controller.mutex.Lock()
	defer controller.mutex.Unlock()
	return controller.configureLocked(config)
}

func (controller *runtimeController) configureLocked(config pluginConfig) error {
	wasRunning := controller.store != nil
	controller.stopWorkersLocked()
	if controller.store != nil {
		_ = controller.store.close()
		controller.store = nil
	}

	store, err := openIPStore(config.DatabasePath)
	if err != nil {
		return err
	}
	settings, err := store.settings()
	if err != nil {
		_ = store.close()
		return err
	}
	if config.WorkerCount != 0 {
		settings.WorkerCount = config.WorkerCount
		if err := store.setSettings(settings); err != nil {
			_ = store.close()
			return err
		}
	}

	controller.store = store
	if !wasRunning {
		_ = store.appendLog(
			logLevelInfo,
			"plugin.configured",
			0,
			"",
			"xAi出口守护插件已启动",
			fmt.Sprintf("数据库 %s，探测线程数 %d，保活线程数 %d，保活间隔 %d 秒", store.path, settings.WorkerCount, settings.KeepaliveWorkerCount, settings.KeepaliveIntervalSeconds),
		)
	}
	controller.startWorkersLocked(store, settings)
	return nil
}

func (controller *runtimeController) ensure() error {
	controller.mutex.Lock()
	defer controller.mutex.Unlock()
	if controller.store != nil {
		return nil
	}
	return controller.configureLocked(pluginConfig{DatabasePath: defaultDatabasePath})
}

func (controller *runtimeController) withStore(fn func(*ipStore) ([]byte, error)) ([]byte, error) {
	controller.mutex.RLock()
	defer controller.mutex.RUnlock()
	if controller.store == nil {
		return nil, fmt.Errorf("plugin store is not initialized")
	}
	return fn(controller.store)
}

func (controller *runtimeController) updateSettings(store *ipStore, settings pluginSettings) error {
	controller.mutex.Lock()
	defer controller.mutex.Unlock()
	if controller.store != store {
		return fmt.Errorf("plugin store changed during settings update")
	}
	if err := store.setSettings(settings); err != nil {
		return err
	}
	controller.stopWorkersLocked()
	controller.startWorkersLocked(store, settings)
	return nil
}

func (controller *runtimeController) startWorkersLocked(store *ipStore, settings pluginSettings) {
	workerContext, cancel := context.WithCancel(context.Background())
	controller.workerCancel = cancel
	for workerIndex := 0; workerIndex < settings.WorkerCount; workerIndex++ {
		controller.workerGroup.Add(1)
		go func() {
			defer controller.workerGroup.Done()
			runProbeWorker(workerContext, store)
		}()
	}
	controller.workerGroup.Add(1)
	go func() {
		defer controller.workerGroup.Done()
		runKeepaliveScheduler(workerContext, store, settings.KeepaliveWorkerCount, settings.KeepaliveIntervalSeconds)
	}()
}

func (controller *runtimeController) stopWorkersLocked() {
	if controller.workerCancel == nil {
		return
	}
	controller.workerCancel()
	controller.workerGroup.Wait()
	controller.workerCancel = nil
}

func (controller *runtimeController) shutdown() {
	controller.mutex.Lock()
	defer controller.mutex.Unlock()
	controller.stopWorkersLocked()
	if controller.store != nil {
		_ = controller.store.appendLog(logLevelInfo, "plugin.shutdown", 0, "", "xAi出口守护插件正在停止", "探测线程已停止")
		_ = controller.store.close()
		controller.store = nil
	}
}
