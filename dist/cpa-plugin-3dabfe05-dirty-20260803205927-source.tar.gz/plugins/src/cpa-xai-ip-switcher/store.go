package main

import (
	"database/sql"
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	_ "github.com/mattn/go-sqlite3"
)

const (
	defaultDatabasePath             = "/opt/cli-proxy-api/plugin-data/cpa-xai-ip-switcher/ip-switcher.sqlite3"
	defaultWorkerCount              = 4
	defaultRefreshIntervalSeconds   = 30
	defaultKeepaliveWorkerCount     = 8
	defaultKeepaliveIntervalSeconds = 300
	maxProbeWorkers                 = 64
	maxRefreshIntervalSeconds       = 3600
	maxKeepaliveIntervalSeconds     = 86400
	maxPluginLogs                   = 1000

	logLevelInfo  = "info"
	logLevelWarn  = "warn"
	logLevelError = "error"

	statusHealthy   = "healthy"
	statusConnected = "connected"
	statusCooldown  = "cooldown"
	statusProbing   = "probing"
	statusUnprobed  = "unprobed"
	statusError     = "error"
	statusAll       = "all"

	probeKindInitial   = "initial"
	probeKindKeepalive = "keepalive"
)

type pluginSettings struct {
	WorkerCount              int
	RefreshIntervalSeconds   int
	KeepaliveWorkerCount     int
	KeepaliveIntervalSeconds int
}

type proxyNode struct {
	ID                int64
	Name              string
	ProxyURL          string
	Host              string
	InputIP           string
	Port              int
	Protocol          string
	Domain            string
	Status            string
	ProbeKind         string
	ProbeReturnStatus string
	KeepaliveRoundID  int64
	LatencyMs         int64
	EnteredAt         int64
	ProbeStartedAt    int64
	ProbeTime         int64
	ExitIP            string
	ErrorReason       string
	ErrorDetail       string
}

type inputLineError struct {
	Line    int    `json:"line"`
	Message string `json:"message"`
}

type pluginLog struct {
	ID        int64
	CreatedAt int64
	Level     string
	Event     string
	NodeID    int64
	NodeName  string
	Message   string
	Detail    string
}

type ipStore struct {
	database *sql.DB
	path     string
}

func openIPStore(path string) (*ipStore, error) {
	resolvedPath, err := resolveDatabasePath(path)
	if err != nil {
		return nil, err
	}
	if err := os.MkdirAll(filepath.Dir(resolvedPath), 0o700); err != nil {
		return nil, fmt.Errorf("create database directory: %w", err)
	}

	database, err := sql.Open("sqlite3", resolvedPath+"?_busy_timeout=5000&_journal_mode=WAL&_foreign_keys=on")
	if err != nil {
		return nil, fmt.Errorf("open sqlite database: %w", err)
	}
	database.SetMaxOpenConns(1)
	database.SetMaxIdleConns(1)
	store := &ipStore{database: database, path: resolvedPath}
	if err := store.initialize(); err != nil {
		_ = database.Close()
		return nil, err
	}
	if err := os.Chmod(resolvedPath, 0o600); err != nil {
		_ = database.Close()
		return nil, fmt.Errorf("protect sqlite database: %w", err)
	}
	return store, nil
}

func resolveDatabasePath(path string) (string, error) {
	path = strings.TrimSpace(path)
	if path == "" {
		path = defaultDatabasePath
	}
	if filepath.IsAbs(path) {
		return filepath.Clean(path), nil
	}
	workingDirectory, err := os.Getwd()
	if err != nil {
		return "", fmt.Errorf("resolve database path: %w", err)
	}
	return filepath.Clean(filepath.Join(workingDirectory, path)), nil
}

func (store *ipStore) initialize() error {
	_, err := store.database.Exec(`
CREATE TABLE IF NOT EXISTS ip_nodes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    node_name TEXT NOT NULL,
    proxy_url TEXT NOT NULL UNIQUE,
    host TEXT NOT NULL,
    input_ip TEXT NOT NULL,
    port INTEGER NOT NULL,
    protocol TEXT NOT NULL,
    domain TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL,
    latency_ms INTEGER NOT NULL DEFAULT 0,
    entered_at INTEGER NOT NULL,
    probe_started_at INTEGER NOT NULL DEFAULT 0,
    probe_kind TEXT NOT NULL DEFAULT '',
    probe_return_status TEXT NOT NULL DEFAULT '',
    keepalive_round_id INTEGER NOT NULL DEFAULT 0,
    probe_time INTEGER NOT NULL DEFAULT 0,
    exit_ip TEXT NOT NULL DEFAULT '',
    error_reason TEXT NOT NULL DEFAULT '',
    error_detail TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_ip_nodes_status_id ON ip_nodes(status, id);
CREATE TABLE IF NOT EXISTS plugin_settings (
    setting_key TEXT PRIMARY KEY,
    setting_value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS plugin_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at INTEGER NOT NULL,
    level TEXT NOT NULL,
    event TEXT NOT NULL,
    node_id INTEGER NOT NULL DEFAULT 0,
    node_name TEXT NOT NULL DEFAULT '',
    message TEXT NOT NULL,
    detail TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_plugin_logs_created_id ON plugin_logs(created_at DESC, id DESC);
INSERT OR IGNORE INTO plugin_settings(setting_key, setting_value) VALUES
    ('worker_count', '4'),
    ('refresh_interval_seconds', '30'),
    ('keepalive_worker_count', '8'),
    ('keepalive_interval_seconds', '300');
DELETE FROM plugin_logs WHERE id NOT IN (SELECT id FROM plugin_logs ORDER BY id DESC LIMIT 1000);
`)
	if err != nil {
		return fmt.Errorf("initialize sqlite database: %w", err)
	}
	if err := store.ensureProbeColumns(); err != nil {
		return err
	}
	_, err = store.database.Exec(`
UPDATE ip_nodes
SET status = CASE
        WHEN probe_kind = 'keepalive' AND probe_return_status IN ('healthy', 'connected', 'cooldown') THEN probe_return_status
        ELSE 'unprobed'
    END,
    probe_started_at = 0,
    probe_kind = '',
    probe_return_status = '',
    keepalive_round_id = 0
WHERE status = 'probing';`)
	if err != nil {
		return fmt.Errorf("reset interrupted sqlite probes: %w", err)
	}
	return nil
}

func (store *ipStore) ensureProbeColumns() error {
	rows, err := store.database.Query(`PRAGMA table_info(ip_nodes)`)
	if err != nil {
		return fmt.Errorf("inspect sqlite node columns: %w", err)
	}
	defer rows.Close()

	columns := make(map[string]bool)
	for rows.Next() {
		var (
			columnID       int
			columnName     string
			columnType     string
			notNull        int
			defaultValue   any
			primaryKeyFlag int
		)
		if err := rows.Scan(&columnID, &columnName, &columnType, &notNull, &defaultValue, &primaryKeyFlag); err != nil {
			return fmt.Errorf("scan sqlite node columns: %w", err)
		}
		columns[columnName] = true
	}
	if err := rows.Err(); err != nil {
		return fmt.Errorf("iterate sqlite node columns: %w", err)
	}
	if err := rows.Close(); err != nil {
		return fmt.Errorf("close sqlite node columns: %w", err)
	}
	for columnName, columnDefinition := range map[string]string{
		"probe_kind":          "TEXT NOT NULL DEFAULT ''",
		"probe_return_status": "TEXT NOT NULL DEFAULT ''",
		"keepalive_round_id":  "INTEGER NOT NULL DEFAULT 0",
	} {
		if columns[columnName] {
			continue
		}
		if _, err := store.database.Exec("ALTER TABLE ip_nodes ADD COLUMN " + columnName + " " + columnDefinition); err != nil {
			return fmt.Errorf("add sqlite node column %s: %w", columnName, err)
		}
	}
	return nil
}

func (store *ipStore) close() error {
	if store == nil || store.database == nil {
		return nil
	}
	return store.database.Close()
}

func (store *ipStore) appendLog(level, event string, nodeID int64, nodeName, message, detail string) (err error) {
	transaction, err := store.database.Begin()
	if err != nil {
		return fmt.Errorf("begin sqlite log insert: %w", err)
	}
	defer func() {
		if err != nil {
			_ = transaction.Rollback()
		}
	}()

	_, err = transaction.Exec(`
INSERT INTO plugin_logs(created_at, level, event, node_id, node_name, message, detail)
VALUES (?, ?, ?, ?, ?, ?, ?)`, time.Now().UnixMilli(), level, event, nodeID, nodeName, message, detail)
	if err != nil {
		return fmt.Errorf("insert sqlite log: %w", err)
	}
	_, err = transaction.Exec(`
DELETE FROM plugin_logs
WHERE id NOT IN (SELECT id FROM plugin_logs ORDER BY id DESC LIMIT ?)`, maxPluginLogs)
	if err != nil {
		return fmt.Errorf("prune sqlite logs: %w", err)
	}
	if err := transaction.Commit(); err != nil {
		return fmt.Errorf("commit sqlite log: %w", err)
	}
	return nil
}

func (store *ipStore) listLogs(search string) ([]pluginLog, error) {
	query := `
SELECT id, created_at, level, event, node_id, node_name, message, detail
FROM plugin_logs`
	arguments := make([]any, 0, 8)
	search = strings.TrimSpace(search)
	if search != "" {
		escapedSearch := strings.NewReplacer(`\`, `\\`, `%`, `\%`, `_`, `\_`).Replace(search)
		searchPattern := "%" + escapedSearch + "%"
		query += `
WHERE level LIKE ? ESCAPE '\'
   OR event LIKE ? ESCAPE '\'
   OR CAST(id AS TEXT) LIKE ? ESCAPE '\'
   OR CAST(node_id AS TEXT) LIKE ? ESCAPE '\'
   OR node_name LIKE ? ESCAPE '\'
   OR message LIKE ? ESCAPE '\'
   OR detail LIKE ? ESCAPE '\'`
		for range 7 {
			arguments = append(arguments, searchPattern)
		}
	}
	query += `
ORDER BY id DESC LIMIT ?`
	arguments = append(arguments, maxPluginLogs)

	rows, err := store.database.Query(query, arguments...)
	if err != nil {
		return nil, fmt.Errorf("list sqlite logs: %w", err)
	}
	defer rows.Close()

	items := make([]pluginLog, 0)
	for rows.Next() {
		var item pluginLog
		if err := rows.Scan(
			&item.ID,
			&item.CreatedAt,
			&item.Level,
			&item.Event,
			&item.NodeID,
			&item.NodeName,
			&item.Message,
			&item.Detail,
		); err != nil {
			return nil, fmt.Errorf("scan sqlite log: %w", err)
		}
		items = append(items, item)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate sqlite logs: %w", err)
	}
	return items, nil
}

func (store *ipStore) insertNodes(nodes []proxyNode) (added, duplicates int, err error) {
	if len(nodes) == 0 {
		return 0, 0, nil
	}
	tx, err := store.database.Begin()
	if err != nil {
		return 0, 0, fmt.Errorf("begin sqlite insert: %w", err)
	}
	defer func() {
		if err != nil {
			_ = tx.Rollback()
		}
	}()

	statement, err := tx.Prepare(`
INSERT OR IGNORE INTO ip_nodes(
    node_name, proxy_url, host, input_ip, port, protocol, domain, status, entered_at
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`)
	if err != nil {
		return 0, 0, fmt.Errorf("prepare sqlite insert: %w", err)
	}
	defer statement.Close()

	enteredAt := time.Now().UnixMilli()
	for _, node := range nodes {
		result, execErr := statement.Exec(
			node.Name,
			node.ProxyURL,
			node.Host,
			node.InputIP,
			node.Port,
			node.Protocol,
			node.Domain,
			statusUnprobed,
			enteredAt,
		)
		if execErr != nil {
			return 0, 0, fmt.Errorf("insert sqlite node: %w", execErr)
		}
		rowsAffected, rowsErr := result.RowsAffected()
		if rowsErr != nil {
			return 0, 0, fmt.Errorf("read sqlite insert result: %w", rowsErr)
		}
		if rowsAffected == 0 {
			duplicates++
		} else {
			added++
		}
	}
	if err := tx.Commit(); err != nil {
		return 0, 0, fmt.Errorf("commit sqlite insert: %w", err)
	}
	return added, duplicates, nil
}

func (store *ipStore) listNodes(status string) ([]proxyNode, error) {
	var (
		rows *sql.Rows
		err  error
	)
	if status == statusAll {
		rows, err = store.database.Query(`
SELECT id, node_name, protocol, status, latency_ms, entered_at, probe_started_at, probe_time, exit_ip, error_reason, error_detail
FROM ip_nodes ORDER BY id DESC`)
	} else {
		rows, err = store.database.Query(`
SELECT id, node_name, protocol, status, latency_ms, entered_at, probe_started_at, probe_time, exit_ip, error_reason, error_detail
FROM ip_nodes WHERE status = ? ORDER BY id DESC`, status)
	}
	if err != nil {
		return nil, fmt.Errorf("list sqlite nodes: %w", err)
	}
	defer rows.Close()

	items := make([]proxyNode, 0)
	for rows.Next() {
		var node proxyNode
		if err := rows.Scan(
			&node.ID,
			&node.Name,
			&node.Protocol,
			&node.Status,
			&node.LatencyMs,
			&node.EnteredAt,
			&node.ProbeStartedAt,
			&node.ProbeTime,
			&node.ExitIP,
			&node.ErrorReason,
			&node.ErrorDetail,
		); err != nil {
			return nil, fmt.Errorf("scan sqlite node: %w", err)
		}
		items = append(items, node)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate sqlite nodes: %w", err)
	}
	return items, nil
}

func (store *ipStore) deleteErrorNodes(errorReason string) (int64, error) {
	result, err := store.database.Exec(`
DELETE FROM ip_nodes WHERE status = ? AND error_reason = ?`, statusError, errorReason)
	if err != nil {
		return 0, fmt.Errorf("delete sqlite error nodes: %w", err)
	}
	deleted, err := result.RowsAffected()
	if err != nil {
		return 0, fmt.Errorf("read sqlite delete result: %w", err)
	}
	return deleted, nil
}

func (store *ipStore) getNode(id int64) (proxyNode, bool, error) {
	var node proxyNode
	err := store.database.QueryRow(`
SELECT id, node_name, protocol, status, latency_ms, entered_at, probe_started_at, probe_time, exit_ip, error_reason, error_detail
FROM ip_nodes WHERE id = ?`, id).Scan(
		&node.ID,
		&node.Name,
		&node.Protocol,
		&node.Status,
		&node.LatencyMs,
		&node.EnteredAt,
		&node.ProbeStartedAt,
		&node.ProbeTime,
		&node.ExitIP,
		&node.ErrorReason,
		&node.ErrorDetail,
	)
	if err == sql.ErrNoRows {
		return proxyNode{}, false, nil
	}
	if err != nil {
		return proxyNode{}, false, fmt.Errorf("get sqlite node: %w", err)
	}
	return node, true, nil
}

func (store *ipStore) claimNext() (*proxyNode, error) {
	tx, err := store.database.Begin()
	if err != nil {
		return nil, fmt.Errorf("begin sqlite claim: %w", err)
	}
	defer tx.Rollback()

	var node proxyNode
	err = tx.QueryRow(`
SELECT id, node_name, proxy_url, host, input_ip, port, protocol, domain
FROM ip_nodes WHERE status = ? ORDER BY id ASC LIMIT 1`, statusUnprobed).Scan(
		&node.ID,
		&node.Name,
		&node.ProxyURL,
		&node.Host,
		&node.InputIP,
		&node.Port,
		&node.Protocol,
		&node.Domain,
	)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, fmt.Errorf("select sqlite claim: %w", err)
	}

	startedAt := time.Now().UnixMilli()
	result, err := tx.Exec(`
UPDATE ip_nodes SET status = ?, probe_started_at = ?, probe_kind = ?, probe_return_status = '', keepalive_round_id = 0, error_reason = '', error_detail = ''
WHERE id = ? AND status = ?`, statusProbing, startedAt, probeKindInitial, node.ID, statusUnprobed)
	if err != nil {
		return nil, fmt.Errorf("update sqlite claim: %w", err)
	}
	rowsAffected, err := result.RowsAffected()
	if err != nil {
		return nil, fmt.Errorf("read sqlite claim result: %w", err)
	}
	if rowsAffected != 1 {
		return nil, fmt.Errorf("sqlite claim lost node %d", node.ID)
	}
	if err := tx.Commit(); err != nil {
		return nil, fmt.Errorf("commit sqlite claim: %w", err)
	}
	node.Status = statusProbing
	node.ProbeKind = probeKindInitial
	node.ProbeReturnStatus = ""
	node.ProbeStartedAt = startedAt
	_ = store.appendLog(
		logLevelInfo,
		"probe.started",
		node.ID,
		node.Name,
		"开始探测节点",
		fmt.Sprintf("协议 %s，目标 %s:%d", node.Protocol, node.Host, node.Port),
	)
	return &node, nil
}

func (store *ipStore) claimNextKeepalive(roundID int64) (*proxyNode, error) {
	transaction, err := store.database.Begin()
	if err != nil {
		return nil, fmt.Errorf("begin sqlite keepalive claim: %w", err)
	}
	defer transaction.Rollback()

	var node proxyNode
	var previousStatus string
	err = transaction.QueryRow(`
SELECT id, node_name, proxy_url, host, input_ip, port, protocol, domain, status
FROM ip_nodes
WHERE status IN (?, ?, ?)
  AND keepalive_round_id <> ?
ORDER BY id ASC LIMIT 1`, statusHealthy, statusConnected, statusCooldown, roundID).Scan(
		&node.ID,
		&node.Name,
		&node.ProxyURL,
		&node.Host,
		&node.InputIP,
		&node.Port,
		&node.Protocol,
		&node.Domain,
		&previousStatus,
	)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, fmt.Errorf("select sqlite keepalive claim: %w", err)
	}

	startedAt := time.Now().UnixMilli()
	result, err := transaction.Exec(`
UPDATE ip_nodes
SET status = ?, probe_started_at = ?, probe_kind = ?, probe_return_status = ?, keepalive_round_id = ?, error_reason = '', error_detail = ''
WHERE id = ? AND status = ? AND keepalive_round_id <> ?`, statusProbing, startedAt, probeKindKeepalive, previousStatus, roundID, node.ID, previousStatus, roundID)
	if err != nil {
		return nil, fmt.Errorf("update sqlite keepalive claim: %w", err)
	}
	rowsAffected, err := result.RowsAffected()
	if err != nil {
		return nil, fmt.Errorf("read sqlite keepalive claim result: %w", err)
	}
	if rowsAffected != 1 {
		return nil, fmt.Errorf("sqlite keepalive claim lost node %d", node.ID)
	}
	if err := transaction.Commit(); err != nil {
		return nil, fmt.Errorf("commit sqlite keepalive claim: %w", err)
	}
	node.Status = statusProbing
	node.ProbeKind = probeKindKeepalive
	node.ProbeReturnStatus = previousStatus
	node.KeepaliveRoundID = roundID
	node.ProbeStartedAt = startedAt
	_ = store.appendLog(
		logLevelInfo,
		"keepalive.started",
		node.ID,
		node.Name,
		"开始保活探测节点",
		fmt.Sprintf("原状态 %s，协议 %s，目标 %s:%d", previousStatus, node.Protocol, node.Host, node.Port),
	)
	return &node, nil
}

func (store *ipStore) completeProbe(node proxyNode, result probeResult) error {
	probeTime := time.Now().UnixMilli()
	if node.ProbeKind == probeKindKeepalive {
		if result.Success {
			_, err := store.database.Exec(`
UPDATE ip_nodes SET status = ?, latency_ms = ?, probe_time = ?, probe_started_at = 0,
    probe_kind = '', probe_return_status = '', exit_ip = ?, error_reason = '', error_detail = ?
WHERE id = ? AND status = ? AND probe_kind = ? AND keepalive_round_id = ?`, node.ProbeReturnStatus, result.LatencyMs, probeTime, result.ExitIP, result.Detail, node.ID, statusProbing, probeKindKeepalive, node.KeepaliveRoundID)
			if err != nil {
				return fmt.Errorf("save keepalive success: %w", err)
			}
			_ = store.appendLog(logLevelInfo, "keepalive.completed", node.ID, node.Name, "节点保活探测成功，状态保持不变", formatProbeResultDetail(result))
			return nil
		}
		_, err := store.database.Exec(`
UPDATE ip_nodes SET status = ?, latency_ms = ?, probe_time = ?, probe_started_at = 0,
    probe_kind = '', probe_return_status = '', keepalive_round_id = 0, exit_ip = ?, error_reason = ?, error_detail = ?
WHERE id = ? AND status = ? AND probe_kind = ? AND keepalive_round_id = ?`, statusError, result.LatencyMs, probeTime, result.ExitIP, result.Reason, result.Detail, node.ID, statusProbing, probeKindKeepalive, node.KeepaliveRoundID)
		if err != nil {
			return fmt.Errorf("save keepalive failure: %w", err)
		}
		_ = store.appendLog(logLevelWarn, "keepalive.failed", node.ID, node.Name, fmt.Sprintf("保活探测失败：%s，节点归类为异常", result.Reason), formatProbeResultDetail(result))
		return nil
	}
	if result.Success {
		_, err := store.database.Exec(`
UPDATE ip_nodes SET status = ?, latency_ms = ?, probe_time = ?, probe_started_at = 0,
    probe_kind = '', probe_return_status = '', exit_ip = ?, error_reason = '', error_detail = ?
WHERE id = ? AND status = ? AND probe_kind = ?`, statusConnected, result.LatencyMs, probeTime, result.ExitIP, result.Detail, node.ID, statusProbing, probeKindInitial)
		if err != nil {
			return fmt.Errorf("save connected probe: %w", err)
		}
		_ = store.appendLog(logLevelInfo, "probe.completed", node.ID, node.Name, "节点探测成功", formatProbeResultDetail(result))
		return nil
	}
	_, err := store.database.Exec(`
UPDATE ip_nodes SET status = ?, latency_ms = ?, probe_time = ?, probe_started_at = 0,
    probe_kind = '', probe_return_status = '', exit_ip = ?, error_reason = ?, error_detail = ?
WHERE id = ? AND status = ? AND probe_kind = ?`, statusError, result.LatencyMs, probeTime, result.ExitIP, result.Reason, result.Detail, node.ID, statusProbing, probeKindInitial)
	if err != nil {
		return fmt.Errorf("save failed probe: %w", err)
	}
	_ = store.appendLog(
		logLevelWarn,
		"probe.failed",
		node.ID,
		node.Name,
		fmt.Sprintf("节点探测失败：%s", result.Reason),
		formatProbeResultDetail(result),
	)
	return nil
}

func (store *ipStore) resetProbe(node proxyNode) error {
	if node.ProbeKind == probeKindKeepalive {
		_, err := store.database.Exec(`
UPDATE ip_nodes SET status = ?, probe_started_at = 0, probe_kind = '', probe_return_status = ''
WHERE id = ? AND status = ? AND probe_kind = ? AND keepalive_round_id = ?`, node.ProbeReturnStatus, node.ID, statusProbing, probeKindKeepalive, node.KeepaliveRoundID)
		if err != nil {
			return fmt.Errorf("reset interrupted keepalive probe: %w", err)
		}
		return nil
	}
	_, err := store.database.Exec(`
UPDATE ip_nodes SET status = ?, probe_started_at = 0, probe_kind = '', probe_return_status = ''
WHERE id = ? AND status = ? AND probe_kind = ?`, statusUnprobed, node.ID, statusProbing, probeKindInitial)
	if err != nil {
		return fmt.Errorf("reset interrupted probe: %w", err)
	}
	return nil
}

func (store *ipStore) summary() (map[string]int64, error) {
	counts := map[string]int64{
		statusHealthy:   0,
		statusConnected: 0,
		statusCooldown:  0,
		statusProbing:   0,
		statusUnprobed:  0,
		statusError:     0,
	}
	rows, err := store.database.Query(`SELECT status, COUNT(*) FROM ip_nodes GROUP BY status`)
	if err != nil {
		return nil, fmt.Errorf("summarize sqlite nodes: %w", err)
	}
	defer rows.Close()
	for rows.Next() {
		var status string
		var count int64
		if err := rows.Scan(&status, &count); err != nil {
			return nil, fmt.Errorf("scan sqlite summary: %w", err)
		}
		counts[status] = count
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate sqlite summary: %w", err)
	}
	return counts, nil
}

func (store *ipStore) settings() (pluginSettings, error) {
	settings := pluginSettings{
		WorkerCount:              defaultWorkerCount,
		RefreshIntervalSeconds:   defaultRefreshIntervalSeconds,
		KeepaliveWorkerCount:     defaultKeepaliveWorkerCount,
		KeepaliveIntervalSeconds: defaultKeepaliveIntervalSeconds,
	}
	rows, err := store.database.Query(`
SELECT setting_key, setting_value
FROM plugin_settings
WHERE setting_key IN ('worker_count', 'refresh_interval_seconds', 'keepalive_worker_count', 'keepalive_interval_seconds')`)
	if err != nil {
		return pluginSettings{}, fmt.Errorf("read plugin settings: %w", err)
	}
	defer rows.Close()

	for rows.Next() {
		var settingKey, rawValue string
		if err := rows.Scan(&settingKey, &rawValue); err != nil {
			return pluginSettings{}, fmt.Errorf("scan plugin settings: %w", err)
		}
		value, err := strconv.Atoi(strings.TrimSpace(rawValue))
		if err != nil {
			continue
		}
		switch settingKey {
		case "worker_count":
			settings.WorkerCount = value
		case "refresh_interval_seconds":
			settings.RefreshIntervalSeconds = value
		case "keepalive_worker_count":
			settings.KeepaliveWorkerCount = value
		case "keepalive_interval_seconds":
			settings.KeepaliveIntervalSeconds = value
		}
	}
	if err := rows.Err(); err != nil {
		return pluginSettings{}, fmt.Errorf("iterate plugin settings: %w", err)
	}
	if err := rows.Close(); err != nil {
		return pluginSettings{}, fmt.Errorf("close plugin settings: %w", err)
	}
	if err := validatePluginSettings(settings); err != nil {
		settings = pluginSettings{
			WorkerCount:              defaultWorkerCount,
			RefreshIntervalSeconds:   defaultRefreshIntervalSeconds,
			KeepaliveWorkerCount:     defaultKeepaliveWorkerCount,
			KeepaliveIntervalSeconds: defaultKeepaliveIntervalSeconds,
		}
		if err := store.setSettings(settings); err != nil {
			return pluginSettings{}, err
		}
	}
	return settings, nil
}

func (store *ipStore) setSettings(settings pluginSettings) error {
	if err := validatePluginSettings(settings); err != nil {
		return err
	}
	transaction, err := store.database.Begin()
	if err != nil {
		return fmt.Errorf("begin settings update: %w", err)
	}
	defer transaction.Rollback()

	settingsToSave := map[string]int{
		"worker_count":               settings.WorkerCount,
		"refresh_interval_seconds":   settings.RefreshIntervalSeconds,
		"keepalive_worker_count":     settings.KeepaliveWorkerCount,
		"keepalive_interval_seconds": settings.KeepaliveIntervalSeconds,
	}
	for settingKey, settingValue := range settingsToSave {
		if _, err := transaction.Exec(`
INSERT INTO plugin_settings(setting_key, setting_value) VALUES (?, ?)
ON CONFLICT(setting_key) DO UPDATE SET setting_value = excluded.setting_value`, settingKey, strconv.Itoa(settingValue)); err != nil {
			return fmt.Errorf("save plugin setting %s: %w", settingKey, err)
		}
	}
	if err := transaction.Commit(); err != nil {
		return fmt.Errorf("commit settings update: %w", err)
	}
	return nil
}

func validatePluginSettings(settings pluginSettings) error {
	if settings.WorkerCount < 1 || settings.WorkerCount > maxProbeWorkers {
		return fmt.Errorf("worker count must be between 1 and %d", maxProbeWorkers)
	}
	if settings.RefreshIntervalSeconds < 5 || settings.RefreshIntervalSeconds > maxRefreshIntervalSeconds {
		return fmt.Errorf("refresh interval must be between 5 and %d seconds", maxRefreshIntervalSeconds)
	}
	if settings.KeepaliveWorkerCount < 1 || settings.KeepaliveWorkerCount > maxProbeWorkers {
		return fmt.Errorf("keepalive worker count must be between 1 and %d", maxProbeWorkers)
	}
	if settings.KeepaliveIntervalSeconds < 1 || settings.KeepaliveIntervalSeconds > maxKeepaliveIntervalSeconds {
		return fmt.Errorf("keepalive interval must be between 1 and %d seconds", maxKeepaliveIntervalSeconds)
	}
	return nil
}
