module github.com/router-for-me/CLIProxyAPI/plugins/src/cpa-claude-mem-adapter

go 1.26.0

require (
	github.com/router-for-me/CLIProxyAPI/v7 v7.0.0
	github.com/tidwall/gjson v1.18.0
	github.com/tidwall/sjson v1.2.5
)

require (
	github.com/tidwall/match v1.1.1 // indirect
	github.com/tidwall/pretty v1.2.0 // indirect
)

replace github.com/router-for-me/CLIProxyAPI/v7 => ../../../
