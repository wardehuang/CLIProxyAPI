module github.com/router-for-me/CLIProxyAPI/plugins/src/cpa-claude-mem-adapter

go 1.22

require (
	github.com/router-for-me/CLIProxyAPI/v7 v7.0.0
	github.com/tidwall/gjson v1.18.0
	github.com/tidwall/sjson v1.2.5
)

replace github.com/router-for-me/CLIProxyAPI/v7 => ../../../
